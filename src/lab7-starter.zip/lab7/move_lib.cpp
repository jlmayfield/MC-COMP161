/*
 Logan Mayfield
*/

#include <iostream>
#include "move_lib.h"

/** movegame::ui  procedures **/

void movegame::ui::displayState(std::ostream& out,
				int loc, int wrap){
  return;	                            
}	       

void movegame::ui::getMove(std::istream& in, int& move){
  return;
}

void movegame::ui::getMoveWithPrompt(std::ostream& out, std::istream& in,
				     int& move){
  return;
}

/**
   TODO (lab)
   * Stub movegame::ui procedure
      - displayLocOnBoard
      - displayWrap
 */

void movegame::ui::movePrompt(std::ostream& out){
  out << "move? ";
  return;
}

/** movegame::model procedures **/

void movegame::model::updateState(int& cur_loc, int& num_wrap, int move){
  return;
}

/**
   TODO (lab)
   * Stub movegame::model procedure
      - boardString
      - wrapString
      - updateLoc
      - updateWrap
      - nextLoc
      - nextWrap
 */

