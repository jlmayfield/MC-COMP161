/*
  Author: Logan Mayfield
  Description: Extra stuff from Lab8
*/

#ifndef _LAB8EXTRA_H_
#define _LAB8EXTRA_H_

#include <string>

namespace lab8extra{
  
  namespace recur{
    /*
      Deletes all of the letter characters from the 
      string s leaving non-letters in the same relative
      order
      @param s string object
      @return none
      @pre none
      @post s no contains only the non-letter characters. 
        their relative order is unchanged.
    */
    void delLetters(std::string& s);

    /*
      Deletes all of the letter characters from index i
      until the beginning of string s leaving non-letters in 
      the same relative order
      @param s string object
      @return none
      @pre none
      @post s from i until the beginning now contains only the 
        non-letter characters. their relative order is unchanged.
    */
    void delLetters(std::string& s, unsigned int i);
    
  }

  namespace iter{
    /*
      Deletes all of the letter characters from the 
      string s leaving non-letters in the same relative
      order
      @param s string object
      @return none
      @pre none
      @post s no contains only the non-letter characters. 
        their relative order is unchanged.
    */
    void delLetters(std::string& s);    

  }

} //end namespace lab8extra


#endif
