/*
  Author: Logan Mayfield
  Description: Lab 8 extras
*/

#include "lab8extra.h"
#include <gtest/gtest.h>

namespace{

  TEST(delLetters,recur){
    std::string s{""};

    lab8extra::recur::delLetters(s);
    EXPECT_EQ(std::string(""),s);
    
    s = "hello";
    lab8extra::recur::delLetters(s);
    EXPECT_EQ(std::string(""),s);
    
    s = "he1l0";
    lab8extra::recur::delLetters(s);
    EXPECT_EQ(std::string("10"),s);

    s = "2001: A Space Odyssey";
    lab8extra::recur::delLetters(s);
    EXPECT_EQ(std::string("2001:   "),s);

  }

  TEST(delLetters,recur2){
    std::string s{""};
    
    lab8extra::recur::delLetters(s,-1);
    EXPECT_EQ(std::string(""),s);
    
    s = "hello";
    lab8extra::recur::delLetters(s,s.length()-1);
    EXPECT_EQ(std::string(""),s);
    
    s = "he1l0";
    lab8extra::recur::delLetters(s,s.length()-1);
    EXPECT_EQ(std::string("10"),s);

    s = "2001: A Space Odyssey";
    lab8extra::recur::delLetters(s,s.length()-1);
    EXPECT_EQ(std::string("2001:   "),s);
    
    s = "2001: A Space Odyssey";
    lab8extra::recur::delLetters(s,3);
    EXPECT_EQ(std::string("2001: A Space Odyssey"),s);
    
    s = "2001: A Space Odyssey";
    lab8extra::recur::delLetters(s,7);
    EXPECT_EQ(std::string("2001:  Space Odyssey"),s);

  }


  TEST(delLetters,iter){
    std::string s{""};

    lab8extra::iter::delLetters(s);
    EXPECT_EQ(std::string(""),s);
    
    s = "hello";
    lab8extra::iter::delLetters(s);
    EXPECT_EQ(std::string(""),s);
    
    s = "he1l0";
    lab8extra::iter::delLetters(s);
    EXPECT_EQ(std::string("10"),s);

    s = "2001: A Space Odyssey";
    lab8extra::iter::delLetters(s);
    EXPECT_EQ(std::string("2001:   "),s);
    
  }


} // end namespace
