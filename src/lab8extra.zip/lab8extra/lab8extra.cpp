/*
  Author: Logan Mayfield
  Description: Lab8 extras
*/

#include <string>
#include "lab8extra.h"

namespace lab8extra{

  void recur::delLetters(std::string& s){
    recur::delLetters(s,s.length()-1);
    return;
  }
    
  void recur::delLetters(std::string& s,unsigned int i){
    if( i >= s.length() ){
      return;
    }

    // if current is a letter, erase it.
    if( isalpha(s[i]) ){
      s.erase(i,1);
    }
    //keep going either way
    delLetters(s,i-1);
    return;

  }
  
  void iter::delLetters(std::string& s){
    
    //auto lets the compiler determine the type
    //based off the initial value
    for(auto i = s.length()-1;  
	i >= 0 && i < s.length() ; //extra careful when counting down
	--i)
      {

	if( isalpha(s[i]) ){
	  // delete the ith character
	  s.erase(i,1);
      }

    }//end for
  
  }

} //end namespace lab8extra
