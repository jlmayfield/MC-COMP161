# Logan Mayfield
#  This is a demonstration python script
#    when run as python demo.py  it will
#    run in "main" mode which means the
#  if __name__ == "__main__" condition
#  is run

import demopack.demomod 
import othermod

def foo(n):
    print("Running foo")
    return 5*n

if __name__ == "__main__":
    print("Running as Main")
    othermod.fee("Whoa Fee")
    x = foo(5)
    print("foo(5) = " + str(x))
    print("demopack.demomod.fee(3,4) = " + str(demopack.demomod.fee(3,4)))
