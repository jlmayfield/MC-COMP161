# Logan Mayfield
#   Another module but this time
#   in the 'main' script directory
#  rather than in a package directory


def fee(s):
    print("other fee go!")
    print(str(s))
