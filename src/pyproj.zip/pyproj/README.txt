This directory demonstrates the basic setup of python programs.
The program proper is the script demo.py. This file contains a local
function definition and is setup to be run as a 'main' script.
The script demo.py pulls other user defined functions from a local
module, othermod.py, and a module named demomod.py within the package
demopack.  Notice that package structure corresponds to directory
structure. It is also important to put a file named __init__.py within
each package directory to ensure proper initialization. The file can
be totally blank but might contain initialization code.

The details of modules and packages are  discussed in section 6 of the
python tutorial. 
