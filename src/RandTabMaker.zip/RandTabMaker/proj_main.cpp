/*
Author:
Description:

*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <random>
#include <cmath>
#include <vector>

int main(int argc, char* argv[]){

  std::ofstream log{"randData.txt"};

  std::default_random_engine prng{1};


  unsigned int max_digits = ceil(log10(prng.max()));
  unsigned int per_line = 70 / (max_digits + 2);

  log << std::left;
  log << "First 20 numbers from seed 1:\n";
  for( int i{0} ; i < 20 ; i++ ){
    log << std::setw(max_digits+2) << prng();
    
    if( i % per_line == (per_line - 1) && i != 19 ){
      log << '\n';
    }
  }
  log << "\n\n";

  
  std::vector<unsigned int> sides = {4,6,8,10,12,20};
  for( unsigned int s : sides ){
    prng.seed(1);
    std::uniform_int_distribution<unsigned int> dice{1,s};
    
    max_digits = ceil(log10(s));
    per_line = 70 / (max_digits + 2);
    
    log << "First 20 numbers from [1," << s << "] with seed 1:\n";
    for( int i{0} ; i < 20 ; ++i ){
      log << std::setw(max_digits+2) << dice(prng);
      
      if( i % per_line == (per_line - 1) && i != 19){
	log << '\n';
      } 

    }
    log << "\n\n";
      
  }
  
  log.close();  

  return 0;
}
