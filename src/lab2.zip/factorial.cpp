/*
  Author: Logan Mayfield
  Date: 1/25/14
  Desc: Implementation of the Factorail library. See factorial.h for 
  detail.  
 */

#include "factorial.h"

// option 1: state the namespace with the name
int ver1::factorial(int n){

  if( n == 0 ){
    return 1;
  }
  else{
    return n * ver1::factorial(n-1);
  }

}

// option 2: nest within the namespace
namespace ver2{

  int factorial(int n){

    int result{1};
    for(int i{2}; i <= n; i++){
      result = result * i;     
    }
    return result;
  }
  
} // end ver2


void ver3::factorial(int n, int& theFact){

  theFact = 1;
  int i{2};
  while( i <= n ){
    theFact *= i;
    i = i + 1;
  }
  return;
  
}

void lab2::printFact(std::ostream& ostr, int n, int ver){
  int fact{0};
  if( ver == 1 ){
    fact = ver1::factorial(n);    
  }
  else if( ver == 2 ){
    fact = ver2::factorial(n);
  }
  else{ //if( ver == 3 )
    ver3::factorial(n,fact);
  }
  
  ostr << "Using version " << ver << ": " <<
    n <<"! = " << fact << '\n';

  return;
}
