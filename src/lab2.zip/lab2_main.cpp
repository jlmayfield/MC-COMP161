/*
  File: lab3_main.cpp
  Author: Logan Mayfield
  Date: 1/25/14
  Desc: Computes a factorial using user directed implementation
*/

// **** INCLUDES ****

#include <iostream> // I/O Library
#include <string> // for string types
#include <sstream> // for using Strings like I/O devices
#include "factorial.h" //factorial library

// **** MAIN PROCEDURE ****

int main(int argc, char* argv[]){
  using namespace std;
  
  // basic error checking on number of CLI inputs
  if ( argc != 3) {
    cerr << "The program " << argv[0] << " requires two inputs. Given only "
	 << argc << ". " << argv[0]
	 << " n ver computes n! using implementaiton ver.\n";
    return 1;
  }

  // three inputs. now convert strings to ints.
  string cli_n(argv[1]);
  string cli_ver(argv[2]);

  // create I/O stringstream from string
  stringstream n_stream(cli_n);
  stringstream ver_stream(cli_ver);

  // variable for user input
  int n = 0;
  int ver = 0;

  // read strings as ints to n and ver respectively
  n_stream >> n;
  ver_stream >> ver;

  // check for bad input values for n
  if( n_stream.fail() || n_stream.bad() ){
    cerr << "The program " << argv[0] <<" could not read the input " << argv[1]
	<<" as an integer value.\n";
    return 1;
  }
  else if( !n_stream.eof() ){
    cout<<"The program " << argv[0] << " found input after "
	<< n << ". Malformed input assumed. Please enter integer value only. \n";
    return 1;
  }
  else if( n < 0 ){
    cout << "The program " << argv[0] <<" expected a positive integer but was given "
	 << n << " instead.\n";
    return 1;
  }

  // check for bad input values for ver
  if( ver_stream.fail() || ver_stream.bad() ){
    cerr<<"The program "<< argv[0] <<" could not read the input "
	<< argv[2] <<" as an integer value.\n";
    return 1;
  }
  else if( !ver_stream.eof() ){
    cerr<<"The program " << argv[0] << " found input after " 
	<< ver << ". Malformed input assume. Please enter integer value only. \n";
    return 1;
  }
  else if( ver < 1 || ver > 4){
    cerr << "The program " << argv[0] <<" requires version number 1,2,3, or 4" <<
      " but was given " << ver << " instead.\n";
    return 1;
  }

  // inputs all check out. let's do this!  
  lab2::printFact(cout , n, ver);
  
  return 0;
}
