/*
  Logan Mayfield
    Test for factorial library procedures
*/

#include "factorial.h"
#include <iostream>
#include <sstream>
#include <gtest/gtest.h>

/*
  Unnammed namespace containing factorial library tests
 */
namespace{

  TEST(ver1,factorial){
    // base case
    EXPECT_EQ(1,ver1::factorial(0));
    EXPECT_EQ(1,ver1::factorial(1));
    // recursive case
    EXPECT_EQ(2,ver1::factorial(2));
    EXPECT_EQ(6,ver1::factorial(3));
    EXPECT_EQ(120,ver1::factorial(5));
  }

  TEST(ver2,factorial){
    // base case
    EXPECT_EQ(1,ver2::factorial(0));
    EXPECT_EQ(1,ver2::factorial(1));
    // recursive case
    EXPECT_EQ(2,ver2::factorial(2));
    EXPECT_EQ(6,ver2::factorial(3));
    EXPECT_EQ(120,ver2::factorial(5));
  }

  TEST(ver3,fact){
    int actual{0};

    // before the mutator actual is 0
    // we'll usuall ommit the before test    
    EXPECT_EQ(0,actual); 
    ver3::factorial(0,actual);
    // after it's 1
    EXPECT_EQ(1,actual);
    actual = 0; //reset the state

    ver3::factorial(1,actual);
    EXPECT_EQ(1,actual);
    actual = 0;

    ver3::factorial(2,actual);
    EXPECT_EQ(2,actual);
    actual = 0; 

    ver3::factorial(3,actual);
    EXPECT_EQ(6,actual);
    actual = 0; 
    
    ver3::factorial(5,actual);
    EXPECT_EQ(120,actual);
    actual = 0; 
    
  }

  TEST(lab2,printfact){
    std::ostringstream actual{""};
    std::string expected{""};

    // We really just need to verify
    // the branching based on version.
    // the factorial is tested indpendently
    // Realistically... there's no way
    // to test the actual branch because
    // the result (n!) is always the same!    
    expected = "Using version 1: 0! = 1\n";
    lab2::printFact(actual,0,1);
    EXPECT_EQ(expected,actual.str());
    //reset the stream
    actual.clear();
    actual.str("");

    expected = "Using version 2: 0! = 1\n";
    lab2::printFact(actual,0,2);
    EXPECT_EQ(expected,actual.str());
    //reset the stream
    actual.clear();
    actual.str("");
    
    expected = "Using version 3: 0! = 1\n";
    lab2::printFact(actual,0,3);
    EXPECT_EQ(expected,actual.str());
    //reset the stream
    actual.clear();
    actual.str("");

  }
  
}
