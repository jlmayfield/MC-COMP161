/*
 * Author: Logan Mayfield
 *  Date: 1/25/14
 *  Desc: Factorial Library. Contains four implementations of
 *  the factorial function. Each implementation is placed in
 *  its own namespace.
 */

#ifndef FACTORIAL_H_
#define FACTORIAL_H_

#include <iostream>

/**
 * The ver1 namespace contains functions for computing factorial
 * using basic structural recursion a la HtDP and COMP160
 */
namespace ver1{
  /**
   *  Compute the factorial of n
   *  @param n integer
   *  @return the factorial of n
   *  @preconditions n>=0
   */
  int factorial (int n);
}

/**
 * Namespace ver2 contaions functions to compute the factorial using
 * an iterative while loop. 
 */
namespace ver2{
  /**
   * Compute the factorial of n
   * @param n integer
   * @return the factorial of n
   * @preconditions n>=0
   */
  int factorial(int n);
}

/**
 * Namespace ver3 implements the iterative factorial as a 
 * mutator procedure rather than a function.
 */
namespace ver3{
  /**
   * Set theFact to n!
   * @param n integer
   * @param theFact variable where n! is stored
   * @return none
   * @preconditions n >= 0
   * @postconditions theFact is now equal to n!
   */
  void factorial(int n, int& theFact);
}

namespace lab2{

  /**
   * Print out a descriptive result for n! computed
   * using version ver
   * @param ostr  the stream where results are printed
   * @param n number whose factoral was computed
   * @param ver version of factorial used for computing
   * @return none
   * @preconditions n >= 0. 1 <= ver <= 3. 
   * @postconditions printed results for n! computed
   * using version ver.
   */
  void printFact(std::ostream& ostr, int n, int ver);

}
	     
#endif
