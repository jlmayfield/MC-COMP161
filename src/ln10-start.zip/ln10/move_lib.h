/**
  Logan Mayfield
*/

#ifndef _MOVE_LIB_H
#define _MOVE_LIB_H

#include <iostream>

namespace movegame{

  //  User Interface Procedures
  namespace ui{
		
    /**
     * Write the board and number of wraps to the stream out
     * @param loc the location of the player
     * @param wrap the number of times wrapped
     * @return none
     * @pre 0<=loc<21 , 0<=wrap
     * @post representation of the game state is written to the
     *   stream out
     */
    void displayState(std::ostream& out,
		      int loc, int wrap);

    /**
     * Get the number of spaces to move from the player
     * @param in the stream where user input can be found
     * @param move the variable where the user's move is stored
     * @return none
     * @pre none
     * @post the user's move (int number of steps) is read from
     *    in
     */						  
    void getMove(std::istream& in, int& move);		

    
    /**
     * Prompt the user for the number of spaces to move and get that 
     *  number from the player 
     * @param out the stream where the prompt is written
     * @param in the stream where user input can be found
     * @param move the variable where the user's move is stored
     * @return none
     * @pre none
     * @post a prompt is written to out and the user's move 
     *  (int number of steps) is read from in
     */						  
    void getMoveWithPrompt(std::ostream& out, std::istream& in, int& move);		

    
  } // end ui


  // Core State/Model Handling Procedure
  namespace model{
	
    /**
     * Modify the location state and wrapped score based on the 
     *   most recent move.
     * @param curr_loc current player location
     * @param num_wrap number of times player has wrapped
     * @return none
     * @pre 0<= cur_loc < 21. 0= num_wrap. 
     * @post curr_loc moved move spaces and num_wrap is 
     *   incremented accordingly 
     */
    void updateState(int& cur_loc, int& num_wrap, int move);
  }

} //end move


#endif
