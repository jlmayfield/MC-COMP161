/*
 Logan Mayfield
*/

#include <iostream>
#include "move_lib.h"

void movegame::ui::displayState(std::ostream& out,
				int loc, int wrap){
  return;	                            
}	       

void movegame::ui::getMove(std::istream& in, int& move){
  return;
}

void movegame::ui::getMoveWithPrompt(std::ostream& out, std::istream& in,
				     int& move){
  return;
}


void movegame::model::updateState(int& cur_loc, int& num_wrap, int move){
  return;
}
