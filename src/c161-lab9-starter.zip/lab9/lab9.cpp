/**
 


 */

#include <vector>
#include "lab9.h"



double lab9::recur::max(const std::vector<double>& v){
  return 0.0;
}

double lab9::iter::max(const std::vector<double>& v){
  return 0.0;
}
