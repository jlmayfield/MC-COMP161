/**


 */

#ifndef LAB9_H_
#define LAB9_H_

#include <vector>

namespace lab9{

  namespace recur{
    /**
     * Find the maximum value in the vector<double> v.
     * @param v the vector
     * @return the max value in v
     * @pre TODO
     * @post TODO
     */
    double max(const std::vector<double>& v);

  }

  namespace iter{
    /**
     * Find the maximum value in the vector<double> v.
     * @param v the vector
     * @return the max value in v
     * @pre TODO
     * @post TODO
     */
    double max(const std::vector<double>& v);

  }
}

#endif
