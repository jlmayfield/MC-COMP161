/**


 */

#include <gtest/gtest.h>
#include <vector>
#include "lab9.h"


namespace {

  TEST(max,iter){
    // TODO
  }

  TEST(max,recur){
    // TODO
  }

}
