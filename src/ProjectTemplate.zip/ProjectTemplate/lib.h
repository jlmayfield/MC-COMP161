/*
  Author:
  Description: Library Declarations and Documentation

*/

#ifndef _LIB_H_
#define _LIB_H_

namespace lib{


} //end namespace lib


#endif
