/*
  Author:
  Description:

*/

#ifndef _LIB_HEAD_H_
#define _LIB_HEAD_H_

namespace lib{


} //end namespace lib


#endif
