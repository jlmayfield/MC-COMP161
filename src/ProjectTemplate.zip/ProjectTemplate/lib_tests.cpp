/*
Author:
Description:

*/

#include "lib_head.h"
#include <gtest/gtest.h>

namespace{

  TEST(stub,stub){}

} // end namespace
