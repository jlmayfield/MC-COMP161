/*
Author:
Description:

*/

#include "lib.h"
#include <gtest/gtest.h>

namespace{

  TEST(stub,stub){}

} // end namespace
