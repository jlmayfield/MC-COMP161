/*
Author:
Description:

*/

#include <iostream>

int main(int argc, char* argv[]){
  using namespace std;

  cout << "Hello " << argv[0] << "!" << endl;

  return 0;
}
