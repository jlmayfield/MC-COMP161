/*
  Author: Logan Mayfield
  Description: An example randomized procedure
*/

#ifndef _LN18_H_
#define _LN18_H_

namespace ln18{

  /*
    Simulate rolling n m-sided dice and get the 
    total of all n dice.
    @param n number of dice
    @param m number of sides per dice
    @param prng instance of the system's uniform random number generator
    @return total from rolling n m-sided dice
    @pre prng has been seeded. m > 0. 
    @post prng produced n new random numbers
   */
  unsigned int ndm(unsigned int n, unsigned int,
		   std::default_random_engine& prng);

} //end namespace ln18


#endif
