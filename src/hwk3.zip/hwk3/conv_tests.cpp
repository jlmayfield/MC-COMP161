/*
Author:
Description:

*/

#include "conversion.h"
#include <gtest/gtest.h>

namespace{

  TEST(intocm,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , inTocm(0.0), 0.0001);
    EXPECT_NEAR(2.54 , inTocm(1.0), 0.0001);
    EXPECT_NEAR(3.81, inTocm(1.5), 0.0001);
    EXPECT_NEAR(25.4 , inTocm(10.0), 0.0001);
  }

  TEST(feettoin,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , feetToIn(0.0), 0.0001);
    EXPECT_NEAR(12.0 , feetToIn(1.0), 0.0001);
    EXPECT_NEAR(18.0 , feetToIn(1.5), 0.0001);
    EXPECT_NEAR(74.4 , feetToIn(6.2), 0.0001);
  }

  TEST(ydtofeet,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , ydToFeet(0.0), 0.0001);
    EXPECT_NEAR(3.0 , ydToFeet(1.0), 0.0001);
    EXPECT_NEAR(4.5 , ydToFeet(1.5), 0.0001);
    EXPECT_NEAR(24.6 , ydToFeet(8.2), 0.0001);
  }

  TEST(rodstoyds,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , rodsToYd(0.0), 0.0001);
    EXPECT_NEAR(5.5 , rodsToYd(1.0), 0.0001);
    EXPECT_NEAR(17.875 , rodsToYd(3.25), 0.0001);
    EXPECT_NEAR(27.5 , rodsToYd(5), 0.0001);

  }

  TEST(furtorod,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , furlongsToRods(0.0), 0.0001);
    EXPECT_NEAR(40.0 , furlongsToRods(1.0), 0.0001);
    EXPECT_NEAR(60.0 , furlongsToRods(1.5), 0.0001);
    EXPECT_NEAR(146.8 , furlongsToRods(3.67), 0.0001);
  }

  TEST(mitofur,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , milesToFurlongs(0.0), 0.0001);
    EXPECT_NEAR(8.0 , milesToFurlongs(1.0), 0.0001);
    EXPECT_NEAR(24.0 , milesToFurlongs(3.0), 0.0001);
    EXPECT_NEAR(36.0 , milesToFurlongs(4.5), 0.0001);
  }

  TEST(fttocm,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , ftToCm(0.0), 0.0001);
    EXPECT_NEAR(30.48 , ftToCm(1.0), 0.0001);
    EXPECT_NEAR(60.96 , ftToCm(2.0), 0.0001);
    EXPECT_NEAR(188.976 , ftToCm(6.2), 0.0001);
  }

  TEST(ydtocm,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , ydsToCm(0.0), 0.0001);
    EXPECT_NEAR(91.44 , ydsToCm(1.0), 0.0001);
    EXPECT_NEAR(310.896 , ydsToCm(3.4), 0.0001);
    EXPECT_NEAR(1311.2496 , ydsToCm(14.34), 0.0001);

  }

  TEST(rodtoin,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , rodsToIn(0.0), 0.0001);
    EXPECT_NEAR(198.0 , rodsToIn(1.0), 0.0001);
    EXPECT_NEAR(693.0 , rodsToIn(3.5), 0.0001);
    EXPECT_NEAR(1063.656 , rodsToIn(5.372), 0.0001);

  }

  TEST(mitoft,all){
    using namespace convert;
    EXPECT_NEAR(0.0 , milesToFt(0.0), 0.0001);
    EXPECT_NEAR(5280.0 , milesToFt(1.0), 0.0001);
    EXPECT_NEAR(18480.0 , milesToFt(3.5), 0.0001);
    EXPECT_NEAR(26928.0 , milesToFt(5.1), 0.0001);

  }

} // end namespace
