/*
  Author: Logan Mayfield
  Description: A unit conversion library

*/

#ifndef _CONVERSION_H_
#define _CONVERSION_H_

namespace convert{

  /**
  * Convert inches to centimeters
  * @param in number of inches
  * @return centimeter equivalent to in
  * @pre in >= 0.0
  */
  double inTocm(double in);

  /**
  * Convert feet to inches
  * @param ft number of feet
  * @return inches equivalent to feet
  * @pre ft >= 0.0
  */
  double feetToIn(double ft);

  /**
  * Convert yards to feet
  * @param yd number of yards
  * @return feet equivalent to yd
  * @pre yd >= 0.0
  */
  double ydToFeet(double yd);

  /**
  * Convert rods to yards
  * @param rd number of rods
  * @return yards equivalent to rd
  * @pre rd >= 0.0
  */
  double rodsToYd(double rd);

  /**
  * Convert furlongs to Rods
  * @param fur number of rods
  * @return rods equivalent to fur
  * @pre fur >= 0.0
  */
  double furlongsToRods(double fur);

  /**
  * Convert miles to furlongs
  * @param mi number of miles
  * @return furlongs equivalent to mi
  * @pre mi >= 0.0
  */
  double milesToFurlongs(double mi);

  /**
  * Convert feet to centimeters
  * @param ft number of feet
  * @return centimeters equivalent to ft
  * @pre ft >= 0.0
  */
  double ftToCm(double ft);

  /**
  * Convert yards to centimeters
  * @param yds number of yards
  * @return centimeters equivalent to yds
  * @pre yds >= 0.0
  */
  double ydsToCm(double yds);

  /**
  * Convert rods to inches
  * @param ft number of feet
  * @return inches equivalent to rds
  * @pre rds >= 0.0
  */
  double rodsToIn(double rds);

  /**
  * Convert miles to feet
  * @param mi number of miles
  * @return feet equivalent to mi
  * @pre mi >= 0.0
  */
  double milesToFt(double mi);


} //end namespace convert


#endif
