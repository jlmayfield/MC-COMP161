/*
Author: Logan Mayfield
Description: Unit tests for the credit library.

*/

#include "credit.h"
#include <gtest/gtest.h>

namespace{

  TEST(payback,all){
    using namespace credit;

    EXPECT_NEAR(0.0,payback(0.0),0.00001);
    EXPECT_NEAR(0.625,payback(250.0),0.00001);
    EXPECT_NEAR(1.25,payback(500.0),0.00001);
    EXPECT_NEAR(2.50,payback(750.0),0.00001);
    EXPECT_NEAR(6.25,payback(1500.0),0.00001);
    EXPECT_NEAR(8.125,payback(1750.0),0.00001);
    EXPECT_NEAR(13.75,payback(2500.0),0.00001);
    EXPECT_NEAR(38.75,payback(5000.0),0.00001);
  }

} // end namespace
