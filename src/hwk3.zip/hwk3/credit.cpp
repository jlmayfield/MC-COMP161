/*
Author: Logan Mayfield
Description: Implementation of the credit library. See
  credit.h for documentation
*/

#include "credit.h"

namespace credit{

  double payback(double charge){


    if(charge <= 500.0 ){ //[0,500]
      return charge * .0025;
    }
    else if(charge <= 1500.0 ){ //(500,1500]
      return 1.25 + (charge-500.0)*.005;
    }
    else if(charge <= 2500.0 ){ //(1500,2500]
      return 6.25 + (charge-1500.0)*0.0075;
    }
    else { // charge > 2500.0
      return 13.75 + (charge-2500.0)*.01;
    }

  }

} //end namespace credit
