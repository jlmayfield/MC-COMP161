/*
Author: Logan Mayfield
Description: Conversion library implementation

*/

#include "conversion.h"

namespace convert{

  double inTocm(double in){
    return in*2.54;
  }

  double feetToIn(double ft){
    return ft*12.0;
  }

  double ydToFeet(double yd){
    return yd*3.0;
  }

  double rodsToYd(double rd){
    return rd*5.5;
  }

  double furlongsToRods(double fur){
    return fur*40.0;
  }

  double milesToFurlongs(double mi){
    return mi*8.0;
  }

  double ftToCm(double ft){
    return inTocm(feetToIn(ft));
  }

  double ydsToCm(double yds){
    return ftToCm(ydToFeet(yds));
  }

  double rodsToIn(double rds){
    return feetToIn(ydToFeet(rodsToYd(rds)));
  }

  double milesToFt(double mi){
    return  rodsToIn(furlongsToRods(milesToFurlongs(mi)))/12.0;
  }


} //end namespace convert
