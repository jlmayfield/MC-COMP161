/*
Author:  Logan Mayfield
Description: hwk3 main. just a hello world stub

*/

#include <iostream>

int main(int argc, char* argv[]){

  std::cout << "Hello World!" << std::endl;

  return 0;
}
