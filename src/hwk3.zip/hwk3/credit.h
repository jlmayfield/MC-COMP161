/*
  Author: Logan Mayfield
  Description: Library for computing credit card payback
    ammount

*/

#ifndef _CREDIT_H_
#define _CREDIT_H_

namespace credit{

  /**
   * Compute the payback ammount for
   * a specific credit card charge value
   * @param charge Ammount charged by customer
   * @return the ammount to be paid back
   * @pre charge >= 0.0
   */
  double payback(double charge);

} //end namespace credit


#endif
