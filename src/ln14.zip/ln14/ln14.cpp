/*
  Author: Logan Mayfield
  Description: Implementations of search and sort
*/

#include <utility> //swap
#include <vector>
#include "ln14.h"

namespace ln14{

  /** SEARCHES **/
  
  int iter::search(const std::vector<int>& data,int key){

    for(unsigned int i{0}; i < data.size() ; ++i){
      if( data[i] == key )
	return i;
    }
    return -1;
  }

  int recur::search(const std::vector<int>& data,int key){
    return recur::search(data,0,data.size(),key);
  }

  int recur::search(const std::vector<int>& data,int fst, int lst, int key){
    if( fst >= lst ){
      return -1;
    }
    else if( data[fst] == key ){
      return fst;
    }
    else{
      return recur::search(data,fst+1,lst,key);
    }      
  }

  /** SORTS **/
  
  void recur::sort(std::vector<int>& data){
    recur::sort(data,0,data.size());
    return;
  }

  void recur::sort(std::vector<int>& data,int fst, int lst){
    if( fst >= lst-1 ){
      return;
    }

    recur::sort(data,fst+1,lst);
    recur::insert(data,fst,lst-1);
    return;
  }

  void recur::insert(std::vector<int>& data,
		     unsigned int fst, unsigned int lst){
    if( fst >= lst ){
      return;
    }

    if( data[fst] > data[fst+1] ){
      std::swap(data[fst],data[fst+1]);
      recur::insert(data,fst+1,lst);
    }
    
  }
  void iter::sort(std::vector<int>& data){

    for(unsigned int i{1}; i < data.size(); i++){
      iter::insert(data,0,i);
    }
    return;
  }

  void iter::insert(std::vector<int>& data,
		   unsigned int fst, unsigned int lst){

    for(unsigned int i{lst-1}; i >= fst && i < data.size(); i--){
      if( data[i+1] < data[i] ){
	std::swap(data[i],data[i+1]);
      }
      else{
	return;
      }
    }
    return;
  }

} //end namespace ln14
