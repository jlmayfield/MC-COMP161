/*
  Author: Logan Mayfield
  Description: Lecture Notes 14 demo code 
*/

#include <iostream>
#include <fstream>
#include <chrono>
#include <random>
#include <vector>
#include <algorithm>


int main(int argc, char* argv[]){
  
  // search data
  std::vector<int> data{1,2,3,4,5,6,7,8,9,10,11};
  // get iterators now so they aren't captured in the timing data
  auto data_fst = begin(data);
  auto data_end = end(data);
  

  // Timing Data
  std::chrono::high_resolution_clock::time_point start;
  std::chrono::high_resolution_clock::time_point end;
  std::chrono::duration< double >  elapsed;

    
  // Gather a single time data point
  start = std::chrono::high_resolution_clock::now();
  std::find(data_fst,data_end,9);
  end = std::chrono::high_resolution_clock::now();

  elapsed = std::chrono::duration_cast< std::chrono::duration<double> >(end-start);

  std::cout << elapsed.count() << " secs\n";
  
  return 0;
}
