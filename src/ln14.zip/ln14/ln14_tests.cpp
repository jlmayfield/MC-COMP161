/*
  Author: Logan Mayfield
  Description: Tests for searchsort library
*/

#include <vector>
#include "ln14.h"
#include <gtest/gtest.h>

namespace{

  TEST(searchrecur,top){

    EXPECT_EQ(-1,ln14::recur::search(std::vector<int>({}),1));
    EXPECT_EQ(-1,ln14::recur::search(std::vector<int>({2}),1));
    EXPECT_EQ(0,ln14::recur::search(std::vector<int>({1}),1));
    EXPECT_EQ(1,ln14::recur::search(std::vector<int>({1,3,5}),3));
    EXPECT_EQ(0,ln14::recur::search(std::vector<int>({1,3,1}),1));
    EXPECT_EQ(2,ln14::recur::search(std::vector<int>({1,3,5}),5));

  }

  TEST(searchrecur,some){
    // search all
    EXPECT_EQ(-1,ln14::recur::search(std::vector<int>({}),0,0,1));
    EXPECT_EQ(1,ln14::recur::search(std::vector<int>({1,2,3,2,1}),0,5,2));
    EXPECT_EQ(-1,ln14::recur::search(std::vector<int>({1,2,3,2,1}),0,5,7));
    // search some
    EXPECT_EQ(3,ln14::recur::search(std::vector<int>({1,2,3,2,1}),2,5,2));
    EXPECT_EQ(-1,ln14::recur::search(std::vector<int>({1,2,3,2,1}),2,3,2));

  }

  TEST(searchiter,all){

    EXPECT_EQ(-1,ln14::iter::search(std::vector<int>({}),1));
    EXPECT_EQ(-1,ln14::iter::search(std::vector<int>({2}),1));
    EXPECT_EQ(0,ln14::iter::search(std::vector<int>({1}),1));
    EXPECT_EQ(1,ln14::iter::search(std::vector<int>({1,3,5}),3));
    EXPECT_EQ(0,ln14::iter::search(std::vector<int>({1,3,1}),1));
    EXPECT_EQ(2,ln14::iter::search(std::vector<int>({1,3,5}),5));

  }

  TEST(insert,all){

    std::vector<int> testme({3,2});
    ln14::iter::insert(testme,0,1);
    EXPECT_EQ(std::vector<int>({2,3}),
	      testme);

    testme = std::vector<int>({2,4,5,7,2,4});
    ln14::iter::insert(testme,0,4);
    EXPECT_EQ(std::vector<int>({2,2,4,5,7,4}),testme);

  }

  TEST(sort,all){

    std::vector<int> sortme;

    ln14::iter::sort(sortme);
    EXPECT_EQ(std::vector<int>({}),
	      sortme);

    sortme = std::vector<int>({1});
    ln14::iter::sort(sortme);
    EXPECT_EQ(std::vector<int>({1}),
	      sortme);

    sortme = std::vector<int>({7,4});
    ln14::iter::sort(sortme);
    EXPECT_EQ(std::vector<int>({4,7}),
	      sortme);

    std::vector<int> data{8,7,6,5,4,3,2,1};
    ln14::iter::sort(data);
    EXPECT_EQ(std::vector<int>({1,2,3,4,5,6,7,8}),
	      data);

  }

} // end namespace
