/*
  Author: Logan Mayfield
  Description: Search and Sort from basic
    recursion and iteration
*/

#ifndef _LN14_H_
#define _LN14_H_

#include <vector>

namespace ln14{
  namespace iter{
    /**
     * Compute the location of the first occurence of the integer key
     * in the vector data.
     * @param data vector of integers
     * @param key search value
     * @return -1 if key is not found, otherwise the index where key
     * is first found
     * @pre none
     * @post none
     */
    int search(const std::vector<int>& data,int key);

    /**
     * Sort the contents of data in least to greatest order
     * @param data vector of integers
     * @return none
     * @pre none
     * @post contents of data have been sorted in least to greatest order
     *  for all i in [0,data.size()-1), data[i] <= data[i+1]
     */
    void sort(std::vector<int>& data);

    /**
     * Move data[lst] into sorted region data[fst..lst-1] such that
     * the whole region is sorted.
     * @param data vector of integers
     * @param fst lowest index of region for insertion
     * @param lst the location of the item to be inserted. Also
     *  one more than the last of the insertion region
     * @pre fst < lst. data[fst .. lst-1] is sorted in
     *  least to greatest order
     * @post data[fst..lst] is sorted in least to greatest order
     */
    void insert(std::vector<int>& data,
  		   unsigned int fst, unsigned int lst);
  }

  namespace recur{

    /**
    *  Same as iter::search(const std::vector<int>,int)
    */
    int search(const std::vector<int>& data,int key);

    /**
     * Compute the location of the first occurence of the integer key
     * in the vector data for the index range [fst,lst).
     * @param data vector of integers
     * @param fst the lower bound of the search range
     * @param lst the excluded upper bound of the search range
     * @param key search value
     * @return -1 if key is not found, otherwise the index where key
     * is first found
     * @pre fst <= lst
     * @post none
     */
    int search(const std::vector<int>& data,int fst, int lst, int key);

    /**
     * Same as iter::sort(std::vector<int>&)
     */
    void sort(std::vector<int>& data);

    /**
     * Sort the contents of data in least to greatest order
     * @param data vector of integers
     * @param fst the lower bound of the sort range
     * @param lst the excluded upper bound of the sort range
     * @return none
     * @pre fst <= lst
     * @post contents of data[fst..lst-1] have been sorted in least to greatest order
     *  for all i in [fst,lst-1), data[i] <= data[i+1]
     */
    void sort(std::vector<int>& data,int fst, int lst);

    /**
     * Move data[lst] into sorted region data[fst..lst-1] such that
     * the whole region is sorted.
     * @param data vector of integers
     * @param fst lowest index of region for insertion
     * @param lst the location of the item to be inserted. Also
     *  one more than the last of the insertion region
     * @pre fst < lst. data[fst .. lst-1] is sorted in
     *  least to greatest order
     * @post data[fst..lst] is sorted in least to greatest order
     */
    void insert(std::vector<int>& data,
  		   unsigned int fst, unsigned int lst);
  }

} //end namespace LN14


#endif
