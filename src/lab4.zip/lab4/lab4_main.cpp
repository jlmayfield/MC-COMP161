/*
  Author: Logan Mayfield 
  Description: Main program lab4 sp15

*/

#include "lab4lib.h"

int main(int argc, char* argv[]){
  using namespace lab4;

  return 0;
}
