/*
  Author: Logan Mayfield
  Description: Functions from lab4 sp15

*/

#ifndef _LAB4LIB_H_
#define _LAB4LIB_H_

namespace lab4{

  /**
   * Determine if character achar is a vowel or not
   * @param achar ASCII character
   * @return true if achar is a vowel, false otherwise
   * @pre none
   */
  bool isVowel(char achar);

  /**
   * Determine if character achar is a consonant or not
   * @param achar ASCII character
   * @return true if achar is a consonant, false otherwise
   * @pre none
   */
  bool isConsonant(char achar);


} //end namespace lab4

namespace alt1{
  /**
   * Determine if character achar is a vowel or not
   * @param achar ASCII character
   * @return true if achar is a vowel, false otherwise
   * @pre none
   */
  bool isVowel(char achar);
}

namespace alt2{
  /**
   * Determine if character achar is a vowel or not
   * @param achar ASCII character
   * @return true if achar is a vowel, false otherwise
   * @pre none
   */
  bool isVowel(char achar);
}

namespace alt3{
  /**
   * Determine if character achar is a vowel or not
   * @param achar ASCII character
   * @return true if achar is a vowel, false otherwise
   * @pre none
   */
  bool isVowel(char achar);
}

namespace alt4{
  /**
   * Determine if character achar is a vowel or not
   * @param achar ASCII character
   * @return true if achar is a vowel, false otherwise
   * @pre none
   */
  bool isVowel(char achar);
}


#endif
