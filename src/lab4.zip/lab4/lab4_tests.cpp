/*
Author: Logan Mayfield
Description: Test for lab 4 sp15

*/

#include "lab4lib.h"
#include <gtest/gtest.h>

namespace{

  TEST(isvowel,positive){
    using namespace lab4;

    EXPECT_TRUE(isVowel('a'));
    EXPECT_TRUE(isVowel('e'));
    EXPECT_TRUE(isVowel('i'));
    EXPECT_TRUE(isVowel('o'));
    EXPECT_TRUE(isVowel('u'));
    EXPECT_TRUE(isVowel('y'));
    EXPECT_TRUE(isVowel('A'));
    EXPECT_TRUE(isVowel('E'));
    EXPECT_TRUE(isVowel('I'));
    EXPECT_TRUE(isVowel('O'));
    EXPECT_TRUE(isVowel('U'));
    EXPECT_TRUE(isVowel('Y'));


  }

  TEST(isvowel,negative){
    using namespace lab4;

    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('r'));
    EXPECT_FALSE(isVowel('t'));
    EXPECT_FALSE(isVowel('L'));
    EXPECT_FALSE(isVowel(' '));
    EXPECT_FALSE(isVowel('\n'));
    EXPECT_FALSE(isVowel('\t'));
    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('\''));
    EXPECT_FALSE(isVowel('*'));

    EXPECT_FALSE(isVowel(0));
    EXPECT_FALSE(isVowel(5));
    EXPECT_FALSE(isVowel(12));

  }

  TEST(isconsonant,negative){
    using namespace lab4;

    EXPECT_FALSE(isConsonant('a'));
    EXPECT_FALSE(isConsonant('e'));
    EXPECT_FALSE(isConsonant('i'));
    EXPECT_FALSE(isConsonant('o'));
    EXPECT_FALSE(isConsonant('u'));
    EXPECT_FALSE(isConsonant('y'));
    EXPECT_FALSE(isConsonant('A'));
    EXPECT_FALSE(isConsonant('E'));
    EXPECT_FALSE(isConsonant('I'));
    EXPECT_FALSE(isConsonant('O'));
    EXPECT_FALSE(isConsonant('U'));
    EXPECT_FALSE(isConsonant('Y'));

    EXPECT_FALSE(isConsonant(' '));
    EXPECT_FALSE(isConsonant('\n'));
    EXPECT_FALSE(isConsonant('\t'));
    EXPECT_FALSE(isConsonant('\''));
    EXPECT_FALSE(isConsonant('*'));

    EXPECT_FALSE(isConsonant(0));
    EXPECT_FALSE(isConsonant(5));
    EXPECT_FALSE(isConsonant(12));

  }

  TEST(isconsonant,positive){
    using namespace lab4;

    EXPECT_TRUE(isConsonant('W'));
    EXPECT_TRUE(isConsonant('w'));
    EXPECT_TRUE(isConsonant('q'));
    EXPECT_TRUE(isConsonant('S'));
    EXPECT_TRUE(isConsonant('p'));
    EXPECT_TRUE(isConsonant('F'));
    EXPECT_TRUE(isConsonant('K'));
    EXPECT_TRUE(isConsonant('C'));
    EXPECT_TRUE(isConsonant('z'));
    EXPECT_TRUE(isConsonant('n'));

  }

  TEST(isvowelalt1,all){
    using namespace alt1;

    EXPECT_TRUE(isVowel('a'));
    EXPECT_TRUE(isVowel('e'));
    EXPECT_TRUE(isVowel('i'));
    EXPECT_TRUE(isVowel('o'));
    EXPECT_TRUE(isVowel('u'));
    EXPECT_TRUE(isVowel('y'));
    EXPECT_TRUE(isVowel('A'));
    EXPECT_TRUE(isVowel('E'));
    EXPECT_TRUE(isVowel('I'));
    EXPECT_TRUE(isVowel('O'));
    EXPECT_TRUE(isVowel('U'));
    EXPECT_TRUE(isVowel('Y'));

    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('r'));
    EXPECT_FALSE(isVowel('t'));
    EXPECT_FALSE(isVowel('L'));
    EXPECT_FALSE(isVowel(' '));
    EXPECT_FALSE(isVowel('\n'));
    EXPECT_FALSE(isVowel('\t'));
    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('\''));
    EXPECT_FALSE(isVowel('*'));

    EXPECT_FALSE(isVowel(0));
    EXPECT_FALSE(isVowel(5));
    EXPECT_FALSE(isVowel(12));

  }

  TEST(isvowelalt2,all){
    using namespace alt2;

    EXPECT_TRUE(isVowel('a'));
    EXPECT_TRUE(isVowel('e'));
    EXPECT_TRUE(isVowel('i'));
    EXPECT_TRUE(isVowel('o'));
    EXPECT_TRUE(isVowel('u'));
    EXPECT_TRUE(isVowel('y'));
    EXPECT_TRUE(isVowel('A'));
    EXPECT_TRUE(isVowel('E'));
    EXPECT_TRUE(isVowel('I'));
    EXPECT_TRUE(isVowel('O'));
    EXPECT_TRUE(isVowel('U'));
    EXPECT_TRUE(isVowel('Y'));

    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('r'));
    EXPECT_FALSE(isVowel('t'));
    EXPECT_FALSE(isVowel('L'));
    EXPECT_FALSE(isVowel(' '));
    EXPECT_FALSE(isVowel('\n'));
    EXPECT_FALSE(isVowel('\t'));
    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('\''));
    EXPECT_FALSE(isVowel('*'));

    EXPECT_FALSE(isVowel(0));
    EXPECT_FALSE(isVowel(5));
    EXPECT_FALSE(isVowel(12));

  }

  TEST(isvowelalt3,all){
    using namespace alt3;

    EXPECT_TRUE(isVowel('a'));
    EXPECT_TRUE(isVowel('e'));
    EXPECT_TRUE(isVowel('i'));
    EXPECT_TRUE(isVowel('o'));
    EXPECT_TRUE(isVowel('u'));
    EXPECT_TRUE(isVowel('y'));
    EXPECT_TRUE(isVowel('A'));
    EXPECT_TRUE(isVowel('E'));
    EXPECT_TRUE(isVowel('I'));
    EXPECT_TRUE(isVowel('O'));
    EXPECT_TRUE(isVowel('U'));
    EXPECT_TRUE(isVowel('Y'));

    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('r'));
    EXPECT_FALSE(isVowel('t'));
    EXPECT_FALSE(isVowel('L'));
    EXPECT_FALSE(isVowel(' '));
    EXPECT_FALSE(isVowel('\n'));
    EXPECT_FALSE(isVowel('\t'));
    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('\''));
    EXPECT_FALSE(isVowel('*'));

    EXPECT_FALSE(isVowel(0));
    EXPECT_FALSE(isVowel(5));
    EXPECT_FALSE(isVowel(12));

  }

  TEST(isvowelalt4,all){
    using namespace alt4;

    EXPECT_TRUE(isVowel('a'));
    EXPECT_TRUE(isVowel('e'));
    EXPECT_TRUE(isVowel('i'));
    EXPECT_TRUE(isVowel('o'));
    EXPECT_TRUE(isVowel('u'));
    EXPECT_TRUE(isVowel('y'));
    EXPECT_TRUE(isVowel('A'));
    EXPECT_TRUE(isVowel('E'));
    EXPECT_TRUE(isVowel('I'));
    EXPECT_TRUE(isVowel('O'));
    EXPECT_TRUE(isVowel('U'));
    EXPECT_TRUE(isVowel('Y'));

    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('r'));
    EXPECT_FALSE(isVowel('t'));
    EXPECT_FALSE(isVowel('L'));
    EXPECT_FALSE(isVowel(' '));
    EXPECT_FALSE(isVowel('\n'));
    EXPECT_FALSE(isVowel('\t'));
    EXPECT_FALSE(isVowel('H'));
    EXPECT_FALSE(isVowel('\''));
    EXPECT_FALSE(isVowel('*'));

    EXPECT_FALSE(isVowel(0));
    EXPECT_FALSE(isVowel(5));
    EXPECT_FALSE(isVowel(12));

  }


} // end namespace
