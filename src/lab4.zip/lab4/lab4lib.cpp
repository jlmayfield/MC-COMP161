/*
Author: Logan Mayfield
Description: Function definitions for lab 4 sp15

*/

#include <cctype>
#include "lab4lib.h"


namespace lab4{

  bool isVowel(char achar){

    return isalpha(achar) &&
      (toupper(achar) == 'A' ||
       toupper(achar) == 'E' ||
       toupper(achar) == 'I' ||
       toupper(achar) == 'O' ||
       toupper(achar) == 'U' ||
       toupper(achar) == 'Y');
  }


  bool isConsonant(char achar){
    return isalpha(achar) && !isVowel(achar);
  }
} // end namespace lab4

namespace alt1{

  bool isVowel(char achar){
    // pre-compute uppercase. save as local
    // variable aUp.
    char aUp{toupper(achar)};

    return aUp == 'A' ||
      aUp == 'E' ||
      aUp == 'I' ||
      aUp == 'O' ||
      aUp == 'U' ||
      aUp == 'Y';
  }
}

namespace alt2{

  bool isVowel(char achar){

    return achar == 'A' || achar == 'a' ||
      achar == 'E' || achar == 'e' ||
      achar == 'I' || achar == 'i' ||
      achar == 'O' || achar == 'o' ||
      achar == 'U' || achar == 'u' ||
      achar == 'Y' || achar == 'y' ;
  }

}

namespace alt3{

  bool isVowel(char achar){
    if ( achar == 'A' || achar == 'a' ||
      	 achar == 'E' || achar == 'e' ||
	       achar == 'I' || achar == 'i' ||
	       achar == 'O' || achar == 'o' ||
	       achar == 'U' || achar == 'u' ||
	       achar == 'Y' || achar == 'y'
       ){
      return true;
    }
    else{
      return false;
    }
  }
}

namespace alt4{

 bool isVowel(char achar){
   if ( achar == 'A' || achar == 'a'){
     return true;
   }
   else if( achar == 'E' || achar == 'e' ){
     return true;
   }
   else if( achar == 'I' || achar == 'i' ){
     return true;
   }
   else if( achar == 'O' || achar == 'o' ){
     return true;
   }
   else if( achar == 'U' || achar == 'u' ){
     return true;
   }
   else if( achar == 'Y' || achar == 'y' ){
     return true;
   }
   else{
      return false;
    }
  }

}
