/*
  Author: Logan Mayfield
  Description: Key searching and sorting algorithms
*/

#ifndef _SEARCHSORT_H_
#define _SEARCHSORT_H_

#include <vector>
#include <random>

namespace searchsort{

  /**
   * Compute the location of the first occurence of the integer key
   * in the vector data.
   * @param data vector of integers
   * @param key search value
   * @return -1 if key is not found, otherwise the index where key
   * is first found
   * @pre none
   * @post none
   */
  int linsearch(const std::vector<int>& data,int key);

  /**
   * Compute the location of an occurence of the integer key
   * in the vector data.
   * @param data vector of integers
   * @param key search value
   * @return -1 if key is not found, otherwise the index where key
   * is first found
   * @pre data is sorted in greastest to least order
   * @post none
   */
  int binsearch(const std::vector<int>& data,int key);

  /**
   * Sort the contents of data in least to greatest order
   * @param data a vector of integers
   * @return none
   * @pre none
   * @post data has been sorted in least to greatest order
   */
  void selectsort(std::vector<int>& data);

  /**
   * Compute the index of the smallest item in data from index
   * range [fst,lst).
   * @param data vector of integers
   * @param fst the first index in the search range
   * @param lst the index after the last index in the search range
   * @return the index from [fst,lst) where the min value for that range
   *   in data can be found
   * @pre 0 <= fst < lst <= data.size() (i.e. data is at least size 1)
   * @post none
   */
  unsigned int min_idx(const std::vector<int>& data,
		       unsigned int fst,unsigned int lst);

  /**
   * Sort the contents of data in least to greatest order
   * @param data vector of integers
   * @return none
   * @pre none
   * @post contents of data have been sorted in least to greatest order
   */
  void insertsort(std::vector<int>& data);

  /**
   * Move data[lst] into sorted region data[fst..lst-1] such that
   * the whole region is sorted.
   * @param data vector of integers
   * @param fst lowest index of region for insertion
   * @param lst the location of the item to be inserted. Also
   *  one more than the last of the insertion region
   * @pre fst < lst. data[fst .. lst-1] is sorted in
   *  least to greatest order
   * @post data[fst..lst] is sorted in least to greatest order
   */
  void insert_last(std::vector<int>& data,
		   unsigned int fst, unsigned int lst);

  /**
   * Sort the contents of data in least to greatest order
   * @param data vector of integers to be sorted
   * @return none
   * @pre none
   * @post data now contains the same numbers but sorted
   */
  void mergesort(std::vector<int>& data);

  /**
   * Sort the contents of data in the index range [first,last] in
   * least to greatest order
   * @param data vector of integers to be sorted
   * @param fst least index of the region to be sorted
   * @param lst greatest index of the region to be sorted
   * @return none
   * @pre fst,lst < data.size()
   * @post data from fst to lst now contains the same numbers but sorted
   */
  void mergesort(std::vector<int>& data,unsigned int fst, unsigned int lst);

  /**
   *
   *@param data vector containing portions to be merged
   *@param lfst least index of left region
   *@param llst greatest index of the left region
   *@param rfst least index of right region
   *@param rlst greatest index of the right region
   *@return none
   *@pre lfst<=llst rfst<=llst llst == rfst-1. data from [lfst,llst] and
   *  [rfst,rlst] are sorted
   *@post data from lfst to rlst is sorted
   */
  void merge(std::vector<int>& data, int lfst, int llst, int rfst, int rlst);

  /**
   * Sort data in least to greatest order
   * @param data the vector to be sorted
   * @return none
   * @pre none
   * @post data is sorted
   */
  void quicksort(std::vector<int>& data);

  /**
   * Sort data in least to greatest order
   * @param data the vector to be sorted
   * @param prng random number generator used in sorting
   * @return none
   * @pre prng has been seeded
   * @post data is sorted and prng has produced O(log(data.size())) numbers
   */
  void quicksort(std::vector<int>& data, std::default_random_engine& prng);

  /**
   * Sort data from fst to least in least to greatest order
   * @param data the vector to be sorted
   * @param fst the least index of the region to sort
   * @param lst the greatest index of the region to sort
   * @param prng random number generator used in sorting
   * @return none
   * @pre prng has been seeded. fst <= lst < data.size()
   * @post data from fst to lst is sorted and prng has produced O(log(|[fst,lst]|) numbers
   */
  void quicksort(std::vector<int>& data,
		 unsigned int fst, unsigned int lst,
		 std::default_random_engine& prng);

  /**
   * Move the numbers in data from fst to lst such that there exists a pivot element where
   * all the items to its left are less than or equal to it and all items to the right are
   * greater than it. The pivot index is returned.
   * @param data vector of integers to be partitioned
   * @param fst least index of the partition space
   * @param lst greatest index of the partition space
   * @param prng random number generated used in pivot selection
   * @return the pivot index
   * @pre fst < lst < data.size()
   * @post for pivot index p, data[fst..p-1] <= data[p] < data[p+1..lst]. One number produced by prng.
   */
  unsigned int partition(std::vector<int>& data,
			 unsigned int fst, unsigned int lst,
			 std::default_random_engine& prng);

} //end namespace searchsort


#endif
