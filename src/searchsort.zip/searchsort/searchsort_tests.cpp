/*
  Author: Logan Mayfield
  Description: Tests for searchsort library
*/

#include <vector>
#include "searchsort.h"
#include <gtest/gtest.h>

namespace{

  TEST(linsearch,all){
    
    EXPECT_EQ(-1,searchsort::linsearch(std::vector<int>({}),1));
    EXPECT_EQ(-1,searchsort::linsearch(std::vector<int>({2}),1));
    EXPECT_EQ(0,searchsort::linsearch(std::vector<int>({1}),1));
    EXPECT_EQ(1,searchsort::linsearch(std::vector<int>({1,3,5}),3));
    EXPECT_EQ(0,searchsort::linsearch(std::vector<int>({1,3,1}),1));
    EXPECT_EQ(2,searchsort::linsearch(std::vector<int>({1,3,5}),5));

  }

  TEST(binsearch,all){
    
    EXPECT_EQ(-1,searchsort::binsearch(std::vector<int>({}),1));
    EXPECT_EQ(-1,searchsort::binsearch(std::vector<int>({2}),1));
    EXPECT_EQ(0,searchsort::binsearch(std::vector<int>({1}),1));
    EXPECT_EQ(1,searchsort::binsearch(std::vector<int>({5,3,1}),3));
    EXPECT_EQ(2,searchsort::binsearch(std::vector<int>({5,3,1}),1));
    EXPECT_EQ(0,searchsort::binsearch(std::vector<int>({5,3,1}),5));
    EXPECT_EQ(3,searchsort::binsearch(std::vector<int>({5,4,3,2,1}),2));
    EXPECT_EQ(-1,searchsort::binsearch(std::vector<int>({8,7,6,5,4,3,2,1}),10));
    EXPECT_EQ(-1,searchsort::binsearch(std::vector<int>({8,7,6,5,4,3,2,1}),0));    
  }

  TEST(min_idx,all){
    
    std::vector<int> data{2,3,394,1,9,8,5,7,9};

    EXPECT_EQ(0,searchsort::min_idx(data,0,1));
    EXPECT_EQ(0,searchsort::min_idx(data,0,3));
    EXPECT_EQ(6,searchsort::min_idx(data,4,data.size()));
    EXPECT_EQ(3,searchsort::min_idx(data,0,data.size()));    
  
  }

  TEST(selectsort,all){
    
    std::vector<int> sortme;

    searchsort::selectsort(sortme);
    EXPECT_EQ(std::vector<int>({}),
	      sortme);

    sortme = std::vector<int>({1});
    searchsort::selectsort(sortme);
    EXPECT_EQ(std::vector<int>({1}),
	      sortme);

    sortme = std::vector<int>({7,4});
    searchsort::selectsort(sortme);
    EXPECT_EQ(std::vector<int>({4,7}),
	      sortme);

    std::vector<int> data{8,7,6,5,4,3,2,1};
    searchsort::selectsort(data);
    EXPECT_EQ(std::vector<int>({1,2,3,4,5,6,7,8}),
	      data);

  }

  TEST(insert_last,all){
    
    std::vector<int> testme({3,2});
    searchsort::insert_last(testme,0,1);
    EXPECT_EQ(std::vector<int>({2,3}),
	      testme);

    testme = std::vector<int>({2,4,5,7,2,4});
    searchsort::insert_last(testme,0,4);
    EXPECT_EQ(std::vector<int>({2,2,4,5,7,4}),testme);
    
  }

  TEST(insertsort,all){
    
    std::vector<int> sortme;

    searchsort::insertsort(sortme);
    EXPECT_EQ(std::vector<int>({}),
	      sortme);

    sortme = std::vector<int>({1});
    searchsort::insertsort(sortme);
    EXPECT_EQ(std::vector<int>({1}),
	      sortme);

    sortme = std::vector<int>({7,4});
    searchsort::insertsort(sortme);
    EXPECT_EQ(std::vector<int>({4,7}),
	      sortme);

    std::vector<int> data{8,7,6,5,4,3,2,1};
    searchsort::insertsort(data);
    EXPECT_EQ(std::vector<int>({1,2,3,4,5,6,7,8}),
	      data);

  }

  TEST(mergesort,all){
    
    std::vector<int> sortme;

    searchsort::mergesort(sortme);
    EXPECT_EQ(std::vector<int>({}),
	      sortme);

    sortme = std::vector<int>({1});
    searchsort::mergesort(sortme);
    EXPECT_EQ(std::vector<int>({1}),
	      sortme);

    sortme = std::vector<int>({7,4});
    searchsort::mergesort(sortme);
    EXPECT_EQ(std::vector<int>({4,7}),
	      sortme);

    std::vector<int> data{8,7,6,5,4,3,2,1};
    searchsort::mergesort(data);
    EXPECT_EQ(std::vector<int>({1,2,3,4,5,6,7,8}),
	      data);
    
  }

  TEST(quicksort,all){
    
    std::vector<int> sortme;

    searchsort::quicksort(sortme);
    EXPECT_EQ(std::vector<int>({}),
	      sortme);

    sortme = std::vector<int>({1});
    searchsort::quicksort(sortme);
    EXPECT_EQ(std::vector<int>({1}),
	      sortme);

    sortme = std::vector<int>({7,4});
    searchsort::quicksort(sortme);
    EXPECT_EQ(std::vector<int>({4,7}),
	      sortme);

    std::vector<int> data{8,7,6,5,4,3,2,1};
    searchsort::quicksort(data);
    EXPECT_EQ(std::vector<int>({1,2,3,4,5,6,7,8}),
	      data);
    
  }


} // end namespace
