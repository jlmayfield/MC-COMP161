/*
  Author: Logan Mayfield
  Description: Implementations for key searching and sorting algorithms
*/

#include <utility> //swap
#include <vector>
#include <random>
#include <chrono>
#include "searchsort.h"

namespace searchsort{

  int linsearch(const std::vector<int>& data,int key){
    
    for(unsigned int i{0}; i < data.size() ; ++i){
      if( data[i] == key )
	return i;
    }
    return -1;
  }

  int binsearch(const std::vector<int>& data,int key){

    int fst{0},mid{0};
    int lst = data.size()-1;
    

    while ( fst <= lst ){
      mid = (lst+fst+1)/2;
      if( data[mid] < key ){
	lst = mid-1;
      }
      else if( data[mid] > key ){
	fst = mid+1;
      }
      else{
	return mid;
      }
    }
    return -1;
  }

  void selectsort(std::vector<int>& data){
    
    for(unsigned int i{0}; i < data.size() ; i++){
      unsigned int next_min_idx = min_idx(data,i,data.size());
      std::swap(data[i],data[next_min_idx]);
    }
  }
  
  unsigned int min_idx(const std::vector<int>& data,
		       unsigned int fst,unsigned int lst){
    
    unsigned int curr_idx = fst;
    for(unsigned int i{fst+1} ; i < lst ; i++ ){
      if( data[curr_idx]  > data[i] ){
	curr_idx = i;
      }
    }
    return curr_idx;
  }

  void insertsort(std::vector<int>& data){
    
    for(unsigned int i{1}; i < data.size(); i++){
      insert_last(data,0,i);
    }
    return;
  }

  void insert_last(std::vector<int>& data, 
		   unsigned int fst, unsigned int lst){
    
    for(unsigned int i{lst-1}; i >= fst && i < data.size(); i--){
      if( data[i+1] < data[i] ){
	std::swap(data[i],data[i+1]);
      }
      else{
	return;
      }
    }
    return;
  }

  void mergesort(std::vector<int>& data){
    if( data.size() > 1 ){
      searchsort::mergesort(data,0,data.size()-1);
    }
    return;
  }

  void mergesort(std::vector<int>& data,unsigned int fst, unsigned int lst){
    if( fst >= lst ){
      return;
    }
    
    int mid = (lst+fst)/2;
    searchsort::mergesort(data,fst,mid);
    searchsort::mergesort(data,mid+1,lst);
    searchsort::merge(data,fst,mid,mid+1,lst);
    
    return;
  }

  void merge(std::vector<int>& data, int lfst, int llst, int rfst, int rlst){

    if( data[llst] <= data[rfst] ){
      //already sorted. no merge needed
      return;
    }

    int lcurr{lfst};
    int rcurr{rfst};
    std::vector<int> merged(rlst-lfst+1);
    unsigned int mcurr{0};

    // get values from both
    while(lcurr <= llst && rcurr <= rlst  ){
      if( data[lcurr] <= data[rcurr] ){
	merged[mcurr] = data[lcurr];
	++lcurr;
      }
      else{
	merged[mcurr] = data[rcurr];
	++rcurr;
      }
      ++mcurr;
    }

    //finish out left
    while( lcurr <= llst ){
	merged[mcurr] = data[lcurr];
	++lcurr;
	++mcurr;
    }

    //finish out right
    while( rcurr <= rlst ){
	merged[mcurr] = data[rcurr];
	++rcurr;
	++mcurr;
    }

    //copy merged to data
    for(unsigned int i{0}; i < merged.size(); ++i){
      data[lfst+i] = merged[i];
    }
    
    return;
  }

  void quicksort(std::vector<int>& data){
    auto clk = std::chrono::system_clock::now();
    auto time_in_ms = clk.time_since_epoch().count();
    std::default_random_engine prng{time_in_ms};
    searchsort::quicksort(data,prng);
    return;
  }
  
  void quicksort(std::vector<int>& data, std::default_random_engine& prng){

    if( data.size() > 1 ){
      searchsort::quicksort(data,0,data.size()-1,prng);
    }
    return;
  }

  void quicksort(std::vector<int>& data, unsigned int fst, unsigned int lst, 
		 std::default_random_engine& prng){
    
    if( fst >= lst || fst >= data.size() || lst >= data.size() ){
      return;
    }

    unsigned int pidx = searchsort::partition(data,fst,lst,prng);
    searchsort::quicksort(data,fst,pidx-1,prng);
    searchsort::quicksort(data,pidx+1,lst,prng);
    return;
  }
  
  unsigned int partition(std::vector<int>& data, 
			 unsigned int fst, unsigned int lst, 
			 std::default_random_engine& prng){

    
    if( fst+1 == lst ){
      // 2 items
      if(data[fst] > data[lst] ){
	// out of order. swap
	std::swap(data[fst],data[lst]);
      }
      // let the pivot be fst
      return fst;
    }

    // 3+ items
    // choose random item for pivot. move to fst
    std::uniform_int_distribution<unsigned int> gen{fst,lst};
    std::swap(data[fst],data[gen(prng)]);

    // set region pointers
    unsigned int last_s1{fst};

    for(unsigned int i{fst+1};i<=lst;++i){
      if( data[i] <= data[fst] ){

	if( last_s1 < (i-1) ){
	  std::swap(data[i],data[last_s1+1]);
	}
	last_s1++;
      }
    }
    
    if( last_s1 != fst ){
      std::swap(data[last_s1],data[fst]);
    }
    return last_s1;
  }  
} //end namespace searchsort
