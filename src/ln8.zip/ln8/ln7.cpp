/*
Author: Logan Mayfield
Description: Example code from Lecture Notes 7

*/

#include <cmath>
#include "ln7.h"

namespace TwoD{

  bool isWithin(double x, double y, double r){
      return r >= sqrt(x*x + y*y);
   }

} //end namespace TwoD
