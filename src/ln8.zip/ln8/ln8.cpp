/*
 Author: Logan Mayfield
 Description: Example code from LN8
*/

#include <string>
#include "ln8.h"

std::string ln8::rest(std::string astr){
  
  // a mutation based solution. modify and return
  astr.erase(0,1);
  return astr;

  // funcitonal, non-mutation based solution with substr
  // return astr.substr(1);
}
