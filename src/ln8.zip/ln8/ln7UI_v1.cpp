/*
Author: Logan Mayfield
Description: Example code from Lecture Notes 7

*/

#include <iostream>
#include "ln7UI.h"

namespace ln7UI{

  void getPoint(double& x,double& y){
    using namespace std;
    cout << "Enter point coordinates: ";
    cin >> x >> y;
    return;
  }

  void getRadius(double& r){
    using namespace std;
    cout << "Enter circle radius: ";
    cin >> r;
    return;
  }

  void reportResults(double x,double y,double r,bool ans){
    using namespace std;
    cout << "isWithin( " << x <<" , " << y << " , " << r << " ) -> " <<
      std::boolalpha << ans << '\n';
    return;
  }

} //end namespace ln7UI
