/*
  Author: Logan Mayfield
  Description: Example Code from Lecture notes 8

*/

#include <string>
#include <sstream>
#include <gtest/gtest.h>
#include "ln8.h"

namespace{

  TEST(strs,all){

    std::string str{"hello"};
    std::string ing{" world!"};

    EXPECT_EQ(std::string("hello"),str);
    EXPECT_EQ(std::string(" world!"),ing);

    // Don't compare C strings to std::string
    //EXPECT_EQ("hello",str);
    //EXPECT_EQ(" world!",ing);

    // Use STREQ for C string comparison
    EXPECT_STREQ("hello",str.c_str());
    EXPECT_STREQ(" world!",ing.c_str());
    EXPECT_STREQ("wierd",std::string("wierd").c_str());

  }

  TEST(strs,funcMethods){

    std::string str{"hello"};
    std::string ing{" world!"};


    // Size/Length
    EXPECT_EQ(5,str.length());
    EXPECT_EQ(5,str.size());

    // Character Selection
    EXPECT_EQ(' ',ing[0]);
    EXPECT_EQ('w',ing[1]);
    EXPECT_EQ(' ',ing.at(0));
    EXPECT_EQ('w',ing.at(1));

    // Substring Selection
    EXPECT_EQ(std::string("ell"), str.substr(1,3));
    EXPECT_EQ(std::string("orld"), ing.substr(2,4));
    EXPECT_EQ(std::string(" wor"), ing.substr(0,4));
    EXPECT_EQ(std::string("ld!"), ing.substr(4));

    // Concatenate
    EXPECT_EQ(std::string("hello world!"), str + ing);

  }


  TEST(strs,effectMethods){

    // The assignment operator with C++ and C strings
    std::string s{""};
    EXPECT_EQ(std::string(""),s); //before
    s = std::string("hello!"); //mutation
    EXPECT_EQ(std::string("hello!") , s); //after .. and before
    s = "world";
    EXPECT_EQ(std::string("world") , s);


    std::string str{"hello"};
    std::string ing{" world!"};

    // std::string append
    EXPECT_EQ(std::string("hello") , str);
    str.append(ing);
    EXPECT_EQ(std::string("hello world!") , str);
    str = "hello"; // reset
    str.append("world!"); //works with C strings too
    EXPECT_EQ(std::string("helloworld!") , str);
    str = "hello"; // reset

    // erase
    EXPECT_EQ(std::string("hello") , str);
    str.erase(0,2);
    EXPECT_EQ(std::string("llo") , str);
    str = "hello";
    str.erase();
    EXPECT_EQ(std::string("") , str);
    str = "hello";
    str.erase(2,3);
    EXPECT_EQ(std::string("he") , str);
    str = "hello";

    // Single character assignment and append
    EXPECT_EQ(std::string("hello") , str);
    str[0] = 'H';
    EXPECT_EQ(std::string("Hello") , str);
    str[2] = 'L';
    EXPECT_EQ(std::string("HeLlo") , str);
    str.at(4) = 'O';
    EXPECT_EQ(std::string("HeLlO") , str);
    str.push_back('!');
    EXPECT_EQ(std::string("HeLlO!") , str);

  }

  TEST(strs,getline){

    std::string first{""};
    std::string last{""};
    std::string name{""};

    std::istringstream sin{"Logan Mayfield"};
    sin >> first >> last;

    EXPECT_EQ(std::string("Logan"),first);
    EXPECT_EQ(std::string("Mayfield"),last);

    name = (first + " " + last);

    EXPECT_EQ(std::string("Logan Mayfield"), name);

    name = "";
    std::istringstream sin2{"Logan Mayfield"};

    std::getline(sin2,name);

    EXPECT_EQ(std::string("Logan Mayfield"), name);
  }

  TEST(istrstrm,all){

    std::istringstream istr{"Hello 1345 3.4 a"};
    std::string s{""};
    int x{0};
    double d{0.0};
    char c{'\0'};

    istr >> s >> x >> d >> c;
    EXPECT_EQ(std::string("Hello") , s);
    EXPECT_EQ(1345 , x);
    EXPECT_DOUBLE_EQ(3.4,d);
    EXPECT_EQ('a', c);

  }

  TEST(ostrstrm,all){

    std::ostringstream sout{""};

    sout << "Hello" << 1345 << 3.4 << 'a';

    EXPECT_EQ(std::string("Hello13453.4a"), sout.str() );

  }

  TEST(rest,all){

    std::string a{"this"};
    std::string b{"his"};

    EXPECT_EQ(b,ln8::rest(a));
    EXPECT_EQ(std::string("is"),ln8::rest(b));
    EXPECT_EQ(std::string("dog"),ln8::rest(std::string(" dog")));

  }
} // end namespace
