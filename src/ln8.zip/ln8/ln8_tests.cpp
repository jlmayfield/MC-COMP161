/*
  Author: Logan Mayfield
  Description: Example Code from Lecture notes 8

*/

#include <string>
#include <sstream>
#include <gtest/gtest.h>
#include "ln8.h"

namespace{

  TEST(strs,all){
    using namespace std;

    string str{"hello"};
    string ing{" world!"};

    EXPECT_EQ(string("hello"),str);
    EXPECT_EQ(string(" world!"),ing);

    // Don't compare C Strings to std::string
    //EXPECT_EQ("hello",str);
    //EXPECT_EQ(" world!",ing);

    // Use STREQ for C String comparison
    EXPECT_STREQ("hello",str.c_str());
    EXPECT_STREQ(" world!",ing.c_str());
    EXPECT_STREQ("wierd",string("wierd").c_str());

  }

  TEST(strs,funcMethods){
    using namespace std;

    string str{"hello"};
    string ing{" world!"};


    // Size/Length
    EXPECT_EQ(5,str.length());
    EXPECT_EQ(5,str.size());

    // Character Selection
    EXPECT_EQ(' ',ing[0]);
    EXPECT_EQ('w',ing[1]);
    EXPECT_EQ(' ',ing.at(0));
    EXPECT_EQ('w',ing.at(1));

    // Substring Selection
    EXPECT_EQ(string("ell"), str.substr(1,3));
    EXPECT_EQ(string("orld"), ing.substr(2,4));
    EXPECT_EQ(string(" wor"), ing.substr(0,4));
    EXPECT_EQ(string("ld!"), ing.substr(4));

    // Concatenate
    EXPECT_EQ(string("hello world!"), str + ing);

  }


  TEST(strs,effectMethods){
    using namespace std;

    // The assignment operator with C++ and C strings
    string s{""};
    EXPECT_EQ(string(""),s); //before
    s = string("hello!"); //mutation
    EXPECT_EQ(string("hello!") , s); //after .. and before
    s = "world";
    EXPECT_EQ(string("world") , s);


    string str{"hello"};
    string ing{" world!"};

    // string append
    EXPECT_EQ(string("hello") , str);
    str.append(ing);
    EXPECT_EQ(string("hello world!") , str);
    str = "hello"; // reset
    str.append("world!"); //works with C strings too
    EXPECT_EQ(string("helloworld!") , str);
    str = "hello"; // reset

    // erase
    EXPECT_EQ(string("hello") , str);
    str.erase(0,2);
    EXPECT_EQ(string("llo") , str);
    str = "hello";
    str.erase();
    EXPECT_EQ(string("") , str);
    str = "hello";
    str.erase(2,3);
    EXPECT_EQ(string("he") , str);
    str = "hello";

    // Single character assignment and append
    EXPECT_EQ(string("hello") , str);
    str[0] = 'H';
    EXPECT_EQ(string("Hello") , str);
    str[2] = 'L';
    EXPECT_EQ(string("HeLlo") , str);
    str.at(4) = 'O';
    EXPECT_EQ(string("HeLlO") , str);
    str.push_back('!');
    EXPECT_EQ(string("HeLlO!") , str);

  }

  TEST(strs,getline){
    using namespace std;

    string first{""};
    string last{""};
    string name{""};

    istringstream sin{"Logan Mayfield"};
    sin >> first >> last;

    EXPECT_EQ(string("Logan"),first);
    EXPECT_EQ(string("Mayfield"),last);

    name = (first + " " + last);

    EXPECT_EQ(string("Logan Mayfield"), name);

    name = "";
    istringstream sin2{"Logan Mayfield"};

    getline(sin2,name);

    EXPECT_EQ(string("Logan Mayfield"), name);
  }

  TEST(istrstrm,all){
    using namespace std;


    istringstream istr{"Hello 1345 3.4 a"};
    string s{""};
    int x{0};
    double d{0.0};
    char c{'\0'};

    istr >> s >> x >> d >> c;
    EXPECT_EQ(string("Hello") , s);
    EXPECT_EQ(1345 , x);
    EXPECT_DOUBLE_EQ(3.4,d);
    EXPECT_EQ('a', c);

  }

  TEST(ostrstrm,all){
    using namespace std;

    ostringstream sout{""};

    sout << "Hello" << 1345 << 3.4 << 'a';

    EXPECT_EQ(string("Hello13453.4a"), sout.str() );

  }

  TEST(rest,all){
  using namespace std;
  using namespace ln8;

  string a{"this"};
  string b{"his"};

  EXPECT_EQ(b,rest(a));
  EXPECT_EQ(string("is"),rest(b));
  EXPECT_EQ(string("dog"),rest(string(" dog")));

  }
} // end namespace
