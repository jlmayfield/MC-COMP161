/*
 Author: Logan Mayfield
 Description: Example code from lecture notes 8
*/

#ifndef _LN8_H_
#define _LN8_H_

#include <string>

namespace ln8{
  /**
   * Return the rest, aka all but the first, of a non-empty string.
   * @param astr A string
   * @return the rest of astr
   * @pre astr.length() > 0
   * @post none
   */
  std::string rest(std::string astr);
}

#endif
