/*

 Logan Mayfield

*/

#include "demo.h"
#include <gtest/gtest.h>


namespace{

  TEST(stub, test){
    FAIL();    
  }
    

} // end namespace
