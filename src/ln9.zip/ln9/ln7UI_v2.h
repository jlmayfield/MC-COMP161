/*
  Author: Logan Mayfield
  Description: Example code from lecture notes 7

*/

#ifndef _LN7UI_H_
#define _LN7UI_H_

namespace ln7UI{

  /*
   * Get (x,y) coordinates from the user
   * @param args the CLI arguments
   * @param x reference to x coordinate variable
   * @param y reference to y coordinate variable
   * @return none
   * @pre args is exactly length 4
   * @post x and y have been assigned values from the user
   */
  void getPoint(char* args[], double& x,double& y);

  /*
   * Get circle radius from the user
   * @param args the CLI arguments
   * @param r reference to circle radius r
   * @return none
   * @pre args is exactly length 4
   * @post r has been assigned values from the user
   */
  void getRadius(char* args[], double& r);

  /*
   * Report results of isWithin for given x,y,r
   * @param x the x coordinate
   * @param y the y coordinate
   * @param r the circle radius
   * @param ans the result of isWithin(x,y,r)
   * @return none
   * @pre ans == TwoD::isWithin(x,y,r)
   * @post Human readable results are printed to stdout
   */
  void reportResults(double x,double y,double r,bool ans);

} //end namespace ln7UI

#endif
