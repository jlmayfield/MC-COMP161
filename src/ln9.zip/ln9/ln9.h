/*
  Author: Logan Mayfield
  Description: Example code from lecture notes 9
*/

#ifndef _LN9_H_
#define _LN9_H_

#include <iostream>

namespace pbr{

  /**
    * Swap the value of two integer variables
    * @param x reference to first int object
    * @param y reference to second int object
    * @return none
    * @pre none
    * @post the values in x and y have been swapped
    */
  void swap(double& x, double& y);

} //end namespace pbr

namespace pbv{

  /**
    * Swap the value of two double variables. This
    * version does not work due to pass-by-value semantics
    * @param x first double
    * @param y second double
    * @return none
    * @pre none
    * @post the values in x and y have been swapped (not really)
    */
  void swap(double x, double y);

} //end namespace pbv

namespace UI{

  /**
   * Retrieve (x,y) coordinates from an input stream
   * @param in input stream where user input is found
   * @param x varibale that stores x coordinate
   * @param y variable that stores y coordinate
   * @return none
   * @pre in will produce two double tokens
   * @post the value of x and y have been changed to data from
   *  the stream
   */
  void getPoint(std::istream& in, double& x, double& y);

  /**
   * Retrieve circle radius r from an input stream
   * @param in input stream where user input is found
   * @param r variable that stores circuit radius
   * @return none
   * @pre in will produce one double token
   * @post the value of r has been changed to data from stream in
   */
  void getRadius(std::istream& in, double& r);

  /**
   * Print results of function isWithin to an output stream
   * @param out the stream where results are printed
   * @param x the x coordinate
   * @param y the y coordinate
   * @param r the circle radius
   * @return none
   * @pre r >= 0.
   * @post Results of isWithin(x,y,r) are printed to out
   */
  void reportResults(std::ostream& out, double x, double y, double r);

  /**
   * Print error message for bad CLI call to output stream
   * @param out output stream for error message
   * @param num_args number of arguments
   * @param cmd_name name of command executable
   * @return none
   * @pre none
   * @post Error message printed to output stream
   */
  void CLIError(std::ostream& err, int num_args, std::string cmd_name);

}

namespace UI2{

  /**
   * Retrieve (x,y) coordinates from an input stream
   * @param in input stream where user input is found
   * @param x varibale that stores x coordinate
   * @param y variable that stores y coordinate
   * @return reference to the input stream
   * @pre in will produce two double tokens
   * @post the value of x and y have been changed to data from
   *  the stream
   */
  std::istream& getPoint(std::istream& in, double& x, double& y);

  /**
   * Retrieve circle radius r from an input stream
   * @param in input stream where user input is found
   * @param r variable that stores circuit radius
   * @return reference to the input stream
   * @pre in will produce one double token
   * @post the value of r has been changed to data from stream in
   */
  std::istream& getRadius(std::istream& in, double& r);

}

#endif
