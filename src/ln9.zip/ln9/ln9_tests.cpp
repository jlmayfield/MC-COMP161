/*
Author: Logan Mayfield
Description: LectureNote 9 tests

*/

#include <iostream>
#include <sstream>
#include <string>
#include "ln9.h"
#include <gtest/gtest.h>

namespace{


  TEST(swap,all){

    double a{3.141};
    double b{2.718};

    EXPECT_DOUBLE_EQ(3.141,a);
    EXPECT_DOUBLE_EQ(2.718,b);

    pbv::swap(a,b); //has no effect

    EXPECT_DOUBLE_EQ(3.141,a);
    EXPECT_DOUBLE_EQ(2.718,b);

    pbr::swap(a,b); //mutates a & b

    EXPECT_DOUBLE_EQ(2.718,a);
    EXPECT_DOUBLE_EQ(3.141,b);

    // the fact that this runs is a sign
    // that PbV isn't what we want. what
    // does it even mean to swap to literals?
    // We don't want to re-invent numbers?!
    pbv::swap(2.3,4.6);

    // this won't even compile. nor should it
    // literals are not objects or variables.
    // they have no l-value
    //pbr::swap(2.3,4.6);

  }

  TEST(getpoint,v1){
    using namespace UI;
    using namespace std;

    istringstream in{"2.3 4.5"};
    double a{0},b{0};

    getPoint(in,a,b);
    EXPECT_DOUBLE_EQ(2.3,a);
    EXPECT_DOUBLE_EQ(4.5,b);
    // check that all of the data was read
    EXPECT_TRUE(in.eof());

  }

  TEST(getradius,v1){
    using namespace UI;
    using namespace std;

    istringstream in{"10"};
    double a{0};

    getRadius(in,a);

    EXPECT_DOUBLE_EQ(10.0,a);
    EXPECT_TRUE(in.eof());
  }

  TEST(reportresults,all){
    using namespace UI;
    using namespace std;

    ostringstream out{""};
    string expected{"isWithin( 2.3 , 4.5 , 10 ) -> true\n"};

    reportResults(out,2.3,4.5,10);

    EXPECT_EQ(expected,out.str());

  }

  TEST(clierr,all){
    using namespace UI;
    using namespace std;

    ostringstream out{""};
    string expected{"Given 1 arguments but expected 3.\n"};
    expected.append("Usage: test! x y r\n");

    UI::CLIError(out,1,string("test!"));

    EXPECT_EQ(expected,out.str());

  }

  TEST(getpoint,v2){
    using namespace UI2;
    using namespace std;

    istringstream in{"2.3 4.5"};
    double a{0},b{0};

    EXPECT_EQ(&in,&getPoint(in,a,b));

    EXPECT_DOUBLE_EQ(2.3,a);
    EXPECT_DOUBLE_EQ(4.5,b);
    EXPECT_TRUE(in.eof());
  }

  TEST(getradius,v2){
    using namespace UI2;
    using namespace std;

    istringstream in{"10"};
    double a{0};

    EXPECT_EQ(&in,&getRadius(in,a));

    EXPECT_DOUBLE_EQ(10.0,a);
    EXPECT_TRUE(in.eof());
  }

} // end namespace
