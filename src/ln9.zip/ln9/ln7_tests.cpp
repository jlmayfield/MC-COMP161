/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include "ln7.h"
#include <gtest/gtest.h>

namespace{

  TEST(isWithin,all){
  using namespace TwoD;

  // Positive Tests
  EXPECT_TRUE(isWithin(0,0,0));
  EXPECT_TRUE(isWithin(0,0,0.5));
  EXPECT_TRUE(isWithin(0,0,2.5));
  EXPECT_TRUE(isWithin(1.0,0.5,2.5));
  EXPECT_TRUE(isWithin(2.5,0.0,2.5));
  EXPECT_TRUE(isWithin(0.0,2.5,2.5));

  // Negative Tests
  EXPECT_FALSE(isWithin(1.0,0,0));
  EXPECT_FALSE(isWithin(0,1.0,0.5));
  EXPECT_FALSE(isWithin(2.5,2.5,2.5));
  EXPECT_FALSE(isWithin(0,0.501,0.5));
  EXPECT_FALSE(isWithin(2.5,0.1,2.5));
  EXPECT_FALSE(isWithin(0.0,3.0,2.5));

  }

} // end namespace
