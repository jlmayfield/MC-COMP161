/*
  Author: Logan Mayfield
  Description: Example code from LN9
*/

#include <iostream>
#include <string>
#include <sstream>
#include "ln7.h"
#include "ln9.h"


int main(int argc, char* argv[]){
  using namespace std;

  double x{0.0},y{0.0},r{0.0};

  if( argc == 1 ) // no arguments, drop to REPL
    while(true){
      cout << "Enter point x & y coordinates and a circle radius r: \n";
      UI2::getRadius(UI2::getPoint(cin,x,y),r);
      UI::reportResults(std::cout,x,y,r);
    }
  else if( argc == 4 ){     istringstream clistrm{string(argv[1]) + "  "+
        string(argv[2]) + " " +
        string(argv[3])};

    UI2::getRadius(UI2::getPoint(clistrm,x,y),r);
    UI::reportResults(cout,x,y,r);
  }
  else{ //argc is not 4 or 1
    UI::CLIError(cerr,argc-1,string(argv[0]));
    return 1;
  }

  return 0;

}
