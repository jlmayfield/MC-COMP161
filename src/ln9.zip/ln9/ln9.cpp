/*
Author: Logan Mayfield
Description: Example code from Lecture Notes 7

*/

#include <iostream>
#include "ln7.h"
#include "ln9.h"


namespace pbr{

  void swap(double& x, double& y){
    double temp = x;
    x = y;
    y = temp;
    return;
  }

} //end namespace pbr

namespace pbv{

  void swap(double x, double y){
    double temp = x;
    x = y;
    y = temp;
    return;
  }

} //end namespace pbv

namespace UI{

  void getPoint(std::istream& in, double& x, double& y){
    in >> x >> y;
    return;
  }

  void getRadius(std::istream& in, double& r){
    in >> r;
    return;
  }

  void reportResults(std::ostream& out, double x, double y, double r){
    out << "isWithin( " << x << " , " << y << " , " << r << " ) -> ";
    out << std::boolalpha << TwoD::isWithin(x,y,r) << "\n";
    return;
  }

  void CLIError(std::ostream& err, int num_args, std::string cmd_name){
    err << "Given " << num_args << " arguments but expected 3.\n";
    err << "Usage: " << cmd_name << " x y r\n";
    return;
  }
} // end namespace UI

namespace UI2{

  std::istream& getPoint(std::istream& in, double& x, double& y){
    in >> x >> y;
    return in;
  }

  std::istream& getRadius(std::istream& in, double& r){
    in >> r;
    return in;
  }

}
