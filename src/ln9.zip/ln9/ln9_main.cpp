/*
  Author: Logan Mayfield
  Description: Example code from LN9
*/

#include <iostream>
#include <string>
#include <sstream>
#include "ln7.h"
#include "ln9.h"


int main(int argc, char* argv[]){
  using namespace std;

  double x{0.0},y{0.0},r{0.0};

  if( argc == 1 ) // no arguments, drop to REPL
    while(true){
      std::cout << "Enter x & y coordinates :";
      UI::getPoint(std::cin,x,y);
      std::cout << "Enter circle radius: ";
      UI::getRadius(std::cin,r);
      UI::reportResults(std::cout,x,y,r);
    }
  else if( argc == 4 ){     istringstream clistrm{string(argv[1]) + "  "+
        string(argv[2]) + " " +
        string(argv[3])};


    UI::getPoint(clistrm,x,y);
    UI::getRadius(clistrm,r);
    UI::reportResults(cout,x,y,r);
  }
  else{ //argc is not 4 or 1
    UI::CLIError(cerr,argc-1,string(argv[0]));
    return 1;
  }

  return 0;

}
