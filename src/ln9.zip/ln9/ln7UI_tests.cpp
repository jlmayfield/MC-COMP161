/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include "ln7UI.h"
#include <iostream>
#include <gtest/gtest.h>

namespace{

  TEST(getPoint,all){
    using namespace ln7UI;

    double x{0.0};
    double y{0.0};

    EXPECT_DOUBLE_EQ(0.0,x);
    EXPECT_DOUBLE_EQ(0.0,y);
    getPoint(x,y); // input 2.5 then 3.5
    EXPECT_DOUBLE_EQ(2.5,x);
    EXPECT_DOUBLE_EQ(3.5,y);
  }

  TEST(getRadius,all){
    using namespace ln7UI;

    double r{0.0};

    EXPECT_DOUBLE_EQ(0.0,r);
    getRadius(r); // input 10
    EXPECT_DOUBLE_EQ(10.0,r);

  }

  TEST(reportResults,all){
    using namespace ln7UI;

    //isWithin( 2.3 , 3.3 , 4.3 ) -> false
    reportResults(2.3,3.3,4.3,false);


  }


} // end namespace
