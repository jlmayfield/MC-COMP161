/*
  Author: Logan Mayfield
  Description: Library Declarations and Documentation for labp2 library
*/

#ifndef _LABP2_H_
#define _LABP2_H_

#include <vector>
#include <random>
#include <ostream>
#include <chrono>

namespace labp2{
  
  /**
   * Compute the vector of integers containing the interval [1,n] sorted
   * in decreasing order.
   * @param n the interval upper bound and vector size
   * @return the vector containing [1,n] in descending order
   * @pre none
   * @post none
   */
  std::vector<int> sorted_ints(unsigned int n);

  /**
   * Compute the vector containing a random permutation of [1,n].
   * @param n the interval upper bound and vector size
   * @param prng a uniform random number generator
   * @pre none
   * @post the prng has produced on the order of n new values
   */
  std::vector<int> rand_ints(unsigned int n, std::default_random_engine& prng);


  /**
   * Write times, in seconds, to the stream as comma seperated values
   * @param out the stream object where times are written 
   * @param times the vector of times as duration <doubles>
   * @return none 
   * @pre none
   * @post times are written to out as comma seperated values
   */
  void write_times(std::ostream& out, 
		   const std::vector< std::chrono::duration< double > >& times);

} //end namespace labp2


#endif
