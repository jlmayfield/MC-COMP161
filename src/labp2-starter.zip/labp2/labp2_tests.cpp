/*
  Author: Logan Mayfield
  Description: Tests for the labp2 library
*/

#include <vector>
#include <random>
#include <algorithm>
#include <sstream>
#include <chrono>
#include "labp2.h"
#include <gtest/gtest.h>

namespace{
  
  TEST(sorted_ints,all){
    
    EXPECT_EQ(std::vector<int>({}),
	      labp2::sorted_ints(0));

    EXPECT_EQ(std::vector<int>({1}),
	      labp2::sorted_ints(1));

    EXPECT_EQ(std::vector<int>({2,1}),
	      labp2::sorted_ints(2));

    EXPECT_EQ(std::vector<int>({8,7,6,5,4,3,2,1}),
	      labp2::sorted_ints(8));
    
  }
  
  TEST(rand_ints,all){
    
    std::default_random_engine gen;

    gen.seed(1);
    EXPECT_EQ(std::vector<int>({}),
	      labp2::rand_ints(0,gen));

    gen.seed(1);
    EXPECT_EQ(std::vector<int>({1}),
	      labp2::rand_ints(1,gen));

    gen.seed(1);
    std::vector<int> expected{6,5,4,3,2,1};
    std::shuffle(begin(expected),end(expected),gen);

    gen.seed(1);
    EXPECT_EQ(expected,labp2::rand_ints(6,gen));
    
  }

  TEST(write_times,all){
    std::ostringstream out;
    std::vector< std::chrono::duration< double > > times;
    
    labp2::write_times(out,times);
    EXPECT_EQ(std::string(""),out.str());

    out.str("");
    out.clear();
    times = { std::chrono::duration< double > (1.0) };
    labp2::write_times(out,times);
    EXPECT_EQ(std::string("1"),out.str());


    out.str("");
    out.clear();
    times = { std::chrono::duration< double > (1.0),
	      std::chrono::duration< double > (2.2)};
    labp2::write_times(out,times);
    EXPECT_EQ(std::string("1,2.2"),out.str());

    out.str("");
    out.clear();
    times = { std::chrono::duration< double > (1.1),
	      std::chrono::duration< double > (2.0),
	      std::chrono::duration< double > (3.14)};
    labp2::write_times(out,times);
    EXPECT_EQ(std::string("1.1,2,3.14"),out.str());

  }
  
} // end namespace
