/*
 * Author:
 * Description: 
 */ 

#include <random>
#include <vector>
#include "labp2.h"


std::vector<int> labp2::sorted_ints(unsigned int n){
  return std::vector<int>({});
}


std::vector<int> labp2::rand_ints(unsigned int n, std::default_random_engine& prng){
  return std::vector<int>({});
}


void labp2::write_times(std::ostream& out, 
			const std::vector< std::chrono::duration< double > >& times){

  return;
}
