

#include <random>
#include <iostream>
#include <sstream>
#include <string>

int main(int argc, char* argv[]){

  if( argc != 3 ){
    std::cerr << "Missing arguments or too many arguments.\n";
      return 1;
  }
  std::istringstream uin_n{argv[1]};
  std::istringstream uin_sd{argv[2]};
  int n{0};
  int sd{0};
  uin_n >> n;
  uin_sd >> sd;

  if( uin_n.fail() || uin_sd.fail() ){
    std::cerr << "Something went wrong. Expected integers but got " << argv[1]
              << ' ' << argv[2] << "\n";
    return 1;
  }

  std::default_random_engine gen;
  gen.seed(sd);

  std::cout << "Seed value: " << sd << '\n';
  for(int i{n-1}; i >= 0; i--){
    std::uniform_int_distribution<int> dist{0,i};
    std::cout << "Random value from [0," << i << "] " << dist(gen) << '\n';
  }
  return 0;
}
