/*
  Author: Logan Mayfield
  Description: Labp2 - linear search profiling 
*/

#include <iostream>
#include <fstream>
#include <chrono>
#include <random>
#include <vector>
#include <algorithm>
#include "labp2.h"

int main(int argc, char* argv[]){
  
  // search data 
  int size{500}; //vector size
  std::vector<int> data(labp2::sorted_ints(size)); // vector
  auto data_fst = std::begin(data); // iterators
  auto data_end = std::end(data);
  
  // elapsed time data goes here
  std::vector< std::chrono::duration< double > > times(size+1);
 
  // timer objects 
  std::chrono::high_resolution_clock::time_point start;
  std::chrono::high_resolution_clock::time_point end;

  for(int key{size} ; key >=0 ; --key){
    
    // get a data sample
    start = std::chrono::high_resolution_clock::now();
    std::find(data_fst,data_end,key);
    end = std::chrono::high_resolution_clock::now();

    // save to vector
    times[size-key] = std::chrono::duration_cast< std::chrono::duration<double> >(end-start);

  }

  // open output file for appending so we can get new data with a re-run. 
  std::ofstream outfile{"labp2.csv",std::ofstream::app};
  // check it
  if( !outfile ){
    std::cerr << "problem opening file\n";
    return 1;
  }

  // write to file and close file
  labp2::write_times(outfile,times);
  outfile.close();
  
  return 0;
}
