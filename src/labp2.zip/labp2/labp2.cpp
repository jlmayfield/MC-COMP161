/*
 * Author:
 * Description:
 */

#include <random>
#include <vector>
#include "labp2.h"


void labp2::fill_sorted(unsigned int n, std::vector<int>& v){
  return;
}


void labp2::fill_rand(unsigned int n, std::vector<int>& v,
                                  std::default_random_engine& prng){
  return;
}
