/*
  Author: Logan Mayfield
  Description: Tests for the labp2 library
*/

#include <vector>
#include <random>
#include <algorithm>
#include <sstream>
#include <chrono>
#include "labp2.h"
#include <gtest/gtest.h>

namespace{

  TEST(sorted_ints,all){

    std::vector<int> actual;

    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_sorted(0,actual);
    EXPECT_EQ(std::vector<int>({}),actual);

    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_sorted(1,actual);
    EXPECT_EQ(std::vector<int>({1}),actual);

    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_sorted(2,actual);
    EXPECT_EQ(std::vector<int>({2,1}), actual);

    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_sorted(8,actual);
    EXPECT_EQ(std::vector<int>({8,7,6,5,4,3,2,1}),actual);

  }

  TEST(rand_ints,all){

    std::default_random_engine gen;
    std::vector<int> actual;

    gen.seed(1);
    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_rand(0,actual,gen);
    EXPECT_EQ(std::vector<int>({}),actual);

    gen.seed(1);
    actual.erase(std::begin(actual),std::end(actual));
    labp2::fill_rand(1,actual,gen);
    EXPECT_EQ(std::vector<int>({1}),actual);

    // Construct a Test for some n > 1
    gen.seed(1);

  }


} // end namespace
