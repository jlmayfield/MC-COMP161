/*
  Author: Logan Mayfield
  Description: Library Declarations and Documentation for labp2 library
*/

#ifndef _LABP2_H_
#define _LABP2_H_

#include <vector>
#include <random>


namespace labp2{

  /**
   * Fill the vecror v with the integers in the interval [1,n] sorted
   * in decreasing order.
   * @param n the interval upper bound
   * @param v the vector reference
   * @return none
   * @pre none
   * @post the vector v now has size n and is filled with [1,n] in
   *   descending order.
   */
  void fill_sorted(unsigned int n, std::vector<int>& v);

  /**
   * Fill the vector v with a random permutation of the integers [1,n].
   * @param n the interval upper bound
   * @param v the vector reference
   * @param prng a uniform random number generator
   * @pre none
   * @post the prng has produced on the order of n new values and v now has
   *  size n and is filled with a random permutation of [1,n]
   */
  void fill_rand(unsigned int n, std::vector<int>& v,
                  std::default_random_engine& prng);


} //end namespace labp2


#endif
