/*
  Author: Logan Mayfield
  Description: Lecture Notes 14 demo code 
*/

#include <iostream>
#include <fstream>
#include <chrono>
#include <random>
#include <vector>
#include <algorithm>
#include "labp2.h"


int main(int argc, char* argv[]){

  const unsigned int size{5000};
  std::vector<int> data{labp2::sorted_ints(size)};
  // get iterators now so they aren't captured in the timing data
  auto data_fst = std::begin(data);
  auto data_end = std::end(data);
  

  // Timing Data variables
  std::chrono::high_resolution_clock::time_point start;
  std::chrono::high_resolution_clock::time_point end;
  std::vector< std::chrono::duration< double > >  elapsed(size+1);

  
  // get all the data for size
  for(unsigned int i{0}; i <= size ; i++){

    
    // Gather a single time data point
    start = std::chrono::high_resolution_clock::now();
    std::find(data_fst,data_end,size-i);
    end = std::chrono::high_resolution_clock::now();

    elapsed[i] = std::chrono::duration_cast< std::chrono::duration<double> >(end-start);
    
  }
  
  std::string fname = std::string("times-")+std::to_string(size)+std::string(".csv");
  std::ofstream times{"times-5000.csv"};
  if( !times ){
    std::cerr << "Error opening log file\n";
    return 1;
  }

  labp2::write_times(times,elapsed);

  return 0;
}
