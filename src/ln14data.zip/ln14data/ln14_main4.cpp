/*
  Author: Logan Mayfield
  Description: Lecture Notes 14 demo code 
*/

#include <iostream>
#include <fstream>
#include <chrono>
#include <random>
#include <vector>
#include <algorithm>
#include "labp2.h"


int main(int argc, char* argv[]){

  const unsigned int size{5000};
  std::vector<int> data;
  std::vector<int> sizes;
  auto data_fst = begin(data);
  auto data_end = end(data);
     

  // Timing Data variables
  std::chrono::high_resolution_clock::time_point start;
  std::chrono::high_resolution_clock::time_point end;

  
  // get all the data for size
  for(unsigned int i{0}; i <= size ; i+=5){

    data = labp2::sorted_ints(i);
    sizes.push_back(i);
    data_fst = std::begin(data);
    data_end = std::end(data);
    std::vector< std::chrono::duration< double > >  elapsed(i+1);
    
    for( unsigned int j{0}; j <= i ; j++ ){
      
      // Gather a single time data point
      start = std::chrono::high_resolution_clock::now();
      std::find(data_fst,data_end,i-j);
      end = std::chrono::high_resolution_clock::now();

      elapsed[j] = std::chrono::duration_cast< std::chrono::duration<double> >(end-start);    
    }
    std::ofstream times;
    if( i > 0 )
      times.open("everything-0to5000.csv",std::ofstream::app);
    else
      times.open("everything-0to5000.csv");


    if( !times ){
      std::cerr << "Error opening log file\n";
      return 1;
    }
    
    labp2::write_times(times,elapsed);
    times << '\n';
    times.close();
  }

  std::ofstream times{"everything-0to5000.csv",std::ofstream::app};
  for(unsigned int i{0}; i < sizes.size(); ++i){
    times << sizes[i];
    if( i < sizes.size()-1 )
      times << ',';
  }
  times.close();

  return 0;
}
