/*
  Author: Logan Mayfield
  Description: Library Definitions
*/

#include <vector>
#include <random>
#include <algorithm>
#include <ostream>
#include <chrono>

#include "labp2.h"

namespace labp2{
  

  std::vector<int> sorted_ints(unsigned int n){
    
    std::vector<int> v(n,0);
    
    for(unsigned int i{0}; i < v.size() ; ++i){
      v[i] = v.size() - i;
    }

    return v;
  }
  
  std::vector<int> rand_ints(unsigned int n, 
			     std::default_random_engine& prng){
    
    std::vector<int> v{labp2::sorted_ints(n)};
    std::shuffle(begin(v),end(v),prng);
    return v;

  }

  void write_times(std::ostream& out, 
		   const std::vector< std::chrono::duration< double > >& times){

    for(unsigned int i{0}; i < times.size() ; ++i){
      out << times[i].count();
      if( i < times.size() -1 )
	out << ",";
    }


    return;
  }

} //end namespace labp2
