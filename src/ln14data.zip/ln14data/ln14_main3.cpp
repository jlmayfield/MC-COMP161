/*
  Author: Logan Mayfield
  Description: Lecture Notes 14 demo code 
*/

#include <iostream>
#include <fstream>
#include <chrono>
#include <random>
#include <vector>
#include <algorithm>
#include "labp2.h"


int main(int argc, char* argv[]){

  const unsigned int size{5000};
  std::vector<int> data;
  auto data_fst = begin(data);
  auto data_end = end(data);
     

  // Timing Data variables
  std::chrono::high_resolution_clock::time_point start;
  std::chrono::high_resolution_clock::time_point end;
  std::vector< std::chrono::duration< double > >  elapsed(size);

  
  // get all the data for size
  for(unsigned int i{0}; i <= size ; i++){

      data = labp2::sorted_ints(i);
      data_fst = std::begin(data);
      data_end = std::end(data);
      
      
      // Gather a single time data point
      start = std::chrono::high_resolution_clock::now();
      std::find(data_fst,data_end,i+1);
      end = std::chrono::high_resolution_clock::now();

      elapsed[i] = std::chrono::duration_cast< std::chrono::duration<double> >(end-start);    
  }
  
  std::ofstream times{"notfound-0to5000.csv"};
  if( !times ){
    std::cerr << "Error opening log file\n";
    return 1;
  }

  labp2::write_times(times,elapsed);

  return 0;
}
