/*
  Author: Logan Mayfield
  Date: 1/25/14
  Desc: Implementation of the Factorail library. See factorial.h for 
  detail.  
 */

#include "factorial.h"

int ver1::factorial(int n){

  if( n == 0 ){
    return 1;
  }
  else{
    return n * ver1::factorial(n-1);
  }

}

int ver2::factorial(int n){
  
  return ver2::factorial_helper(n,1);

}

int ver2::factorial_helper(int n,int accum){

  if( n == 0 ){
    return accum;
  }
  else{
    return ver2::factorial_helper(n-1,accum*n);
  }
}


int ver3::factorial(int n){

  int ret_val(1);

  factorial_helper(n,ret_val);

  return ret_val;
}

void ver3::factorial_helper(int n,int &accum){

  if( n == 0 ){
    return;
  }
  else{
    accum = accum * n;
    ver3::factorial_helper(n-1,accum);
    return;
  }
}

int ver4::factorial(int n){
  
  int accum = 1;
  while( n > 1 ){
    accum = accum * n;
    n = n - 1;
  }
  return accum;
}
