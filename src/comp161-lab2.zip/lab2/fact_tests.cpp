
#include "factorial.h"
#include <gtest/gtest.h>

/*
  Unnammed namespace containing factorial library tests
 */
namespace{

  TEST(ver1,factorial){
    // base case
    EXPECT_EQ(1,ver1::factorial(0));
    EXPECT_EQ(1,ver1::factorial(1));
    // recursive case
    EXPECT_EQ(2,ver1::factorial(2));
    EXPECT_EQ(6,ver1::factorial(3));
    EXPECT_EQ(120,ver1::factorial(5));
  }

  TEST(ver2,factorial){
    // base case
    EXPECT_EQ(1,ver2::factorial(0));
    EXPECT_EQ(1,ver2::factorial(1));
    // recursive case
    EXPECT_EQ(2,ver2::factorial(2));
    EXPECT_EQ(6,ver2::factorial(3));
    EXPECT_EQ(120,ver2::factorial(5));
  }

  TEST(ver2,factHelper){
    // base case 
    EXPECT_EQ(1,ver2::factorial_helper(0,1));
    EXPECT_EQ(1,ver2::factorial_helper(1,1));
    EXPECT_EQ(5,ver2::factorial_helper(1,5));
    EXPECT_EQ(17,ver2::factorial_helper(1,17));
    // recursive case 
    EXPECT_EQ(2,ver2::factorial_helper(2,1));
    EXPECT_EQ(6,ver2::factorial_helper(3,1));
    EXPECT_EQ(120,ver2::factorial_helper(5,1));
    EXPECT_EQ(6,ver2::factorial_helper(2,3));
    EXPECT_EQ(240,ver2::factorial_helper(5,2));
    EXPECT_EQ(24,ver2::factorial_helper(3,4));
  }
  
  TEST(ver3,factorial){
    //base case 
    EXPECT_EQ(1,ver3::factorial(0));
    EXPECT_EQ(1,ver3::factorial(1));
    // recursive case 
    EXPECT_EQ(2,ver3::factorial(2));
    EXPECT_EQ(6,ver3::factorial(3));
    EXPECT_EQ(120,ver3::factorial(5));
  }

  TEST(ver3,factHelper){
    //base case 
    int test = 1;
    EXPECT_EQ(1,test); //before
    ver3::factorial_helper(0,test); //mutator
    EXPECT_EQ(1,test); //after

    test = 1;
    EXPECT_EQ(1,test); //before
    ver3::factorial_helper(1,test); //mutator
    EXPECT_EQ(1,test); //after

    // recursive case 
    test = 1;
    EXPECT_NE(2,test); //before
    ver3::factorial_helper(2,test); //mutator
    EXPECT_EQ(2,test); //after

    test = 1;
    EXPECT_NE(6,test); //before
    ver3::factorial_helper(3,test); //mutator
    EXPECT_EQ(6,test); //after
    
    test = 1;
    EXPECT_NE(120,test); //before
    ver3::factorial_helper(5,test); //mutator
    EXPECT_EQ(120,test); //after
    
  }
  
  TEST(ver4,factorial){
    // base case 
    EXPECT_EQ(1,ver4::factorial(0));
    EXPECT_EQ(1,ver4::factorial(1));
    // recursive case 
    EXPECT_EQ(2,ver4::factorial(2));
    EXPECT_EQ(6,ver4::factorial(3));
    EXPECT_EQ(120,ver4::factorial(5));
  }
  
}
