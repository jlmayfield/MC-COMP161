/*
  Author: Logan Mayfield
  Date: 1/25/14
  Desc: Factorial Library. Contains four implementations of 
  the factorial function. Each implementation is placed in
  its own namespace.

*/

#ifndef FACTORIAL_H_
#define FACTORIAL_H_

/*
  The ver1 namespace contains functions for computing factorial
  using basic structural recursion a la HtDP and COMP160
 */
namespace ver1{
  /*
    factorial: int -> int
      Compute the factorial of n
      @input n integer
      @return the factorial of n
      @preconditions n>=0
      @postconditions none
   */
  int factorial (int n);
}


/*
  Namespace ver2 contains functions for computing the factorial 
  using accumulator style recursion, or iterative recursion. 
 */
namespace ver2{
  /*
    factorial: int -> int
      Compute the factorial of n
      @input n integer
      @return the factorial of n
      @preconditions n>=0
      @postconditions none
   */
  int factorial (int n);
  
  /*
    factorial_helper: int int -> int
     computes and returns n!*accum
     @input n any natural number
     @input accum postive, non-zero natural number
     @return n!*accum
     @precondtions: n>=0 and accum>=1
     @postconditions: none    
   */
  int factorial_helper(int n, int accum);
}


/*
  Namespace ver3 contains functions for computing the factorial using
  accumulator recursion and a state variable for accumulation.
 */
namespace ver3{
  
    /*
    factorial: int -> int
      Compute the factorial of n
      @input n integer
      @return the factorial of n
      @preconditions n>=0
      @postconditions none
   */
  int factorial (int n);

  /*
    factorial_helper: int int& -> void
     Compute n!*accum and store result back to accum. This procedure
     is a mutator for the state variable accum.
    @input n any natural number
    @input accum state variable reference 
    @output none
    @preconditions: n>=0 and accum>=1
    @postconditions: accum modified to accum*n!
   */
  void factorial_helper(int n, int &accum);
}

/*
  Namespace ver4 contaions functions to compute the factorial using 
  an iterative while loop.
 */
namespace ver4{
  /*
    factorial: int -> int
    Compute the factorial of n
    @input n integer
    @return the factorial of n
    @preconditions n>=0
    @postconditions none
  */
  int factorial(int n);
}

#endif
