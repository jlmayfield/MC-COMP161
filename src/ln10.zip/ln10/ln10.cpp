/*
  Author: Logan Mayfield
  Description: Lecture Notes 10 example code

*/

#include <string>
#include <cctype>
#include "ln10.h"

namespace iter{

  void setStrToUpper(std::string& str){

    for(unsigned int i{0}; i < str.length(); ++i ){
      // set str[i] to the uppercase version of its current contents
      str[i] = toupper(str[i]);
    }
    return;
  }

  namespace ver2{

    std::string strToUpper(std::string str){

      std::string acc{""};

      for(unsigned int i{0}; i < str.length(); ++i ){
	// accumulate the next uppercase letter
	acc.push_back(toupper(str[i]));
      }

      return acc;
    }

  } //end ver2

  namespace ver3{

    std::string strToUpper(std::string str){

      for(unsigned int i{0}; i < str.length(); ++i ){
	// set str[i] to the uppercase version of its current contents
        str[i] = toupper(str[i]);
      }

      return str;
    }

  } //end ver3

  namespace ver4{

    std::string strToUpper(std::string str){

      std::string acc{""};
      // add enough space for new characters
      acc.reserve(str.length());

      for(unsigned int i{0}; i < str.length(); ++i ){
	acc.push_back(toupper(str[i]));
      }

      return acc;
    }


  } //end ver4

} //end namespace iter

namespace recur{

  std::string strToUpper(std::string str){
    if( str.empty() ){
      return std::string("");
    }
    else{ //not empty
      return std::string(1,toupper(str[0])) +
	strToUpper(str.substr(1));
    }
  }

  namespace badIdea{

    void setStrToUpper(std::string& str){

      if( str.empty() ){
	return;
      }

      // upper the first
      str[0] = toupper(str[0]);

      // upper the rest
      std::string rst{str.substr(1)}; //get the rest
      setStrToUpper(rst); // uppercase the rest
      str.replace(1,str.length()-1,rst); //str's rest to rst

      return;

    } // end setStrToUpper

  }// end badIdea

  void setStrToUpper(std::string& str, unsigned int i){

    if( i == str.length() ){ // empty!
      return;
    }

    str[i] = toupper(str[i]); // set the "first"
    setStrToUpper(str,i+1); // set the "rest"
    return;
  }

  void setStrToUpper(std::string& str){

    setStrToUpper(str,0);
    return;
  }


}
