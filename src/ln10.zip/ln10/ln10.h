/*
  Author: Logan Mayfield
  Description: Lecture Notes 10 example code
*/

#ifndef _LN10_H_
#define _LN10_H_

#include <string>

/**
 * strToUpper compute the uppercase version of std::string str
 * @param str the string
 * @return str in all uppercase
 * @pre str is composed of alphabetic characters only
 * @post none
 */

/**
 * setStrToUpper changes all the letters of std::string str
 *  to their uppercase counterparts
 * @param str the std::string object getting modified
 * @return none
 * @pre str is composed of alphabetic characters only
 * @post str is now the same letters, in the same order, but uppercase
 */

/*
  Iterative Solutions
*/
namespace iter{

  void setStrToUpper(std::string& str);

  namespace ver1{
    std::string strToUpper(std::string str);
  }

  namespace ver2{
    std::string strToUpper(std::string str);
  }

  namespace ver3{
    std::string strToUpper(std::string str);
  }

  namespace ver4{
    std::string strToUpper(std::string str);
  }

} //end namespace iter

/*
  Rescursive solutions
*/
namespace recur{

  std::string strToUpper(std::string str);


  namespace badIdea{
    void setStrToUpper(std::string& str);
  }

  void setStrToUpper(std::string& str);
  /*
    Set all the letters from i to the end of str to their upper case counterparts
    @param str the string object getting modified
    @param i the lowest location to be modified
    @return none
    @pre str is all alphabetic letters. 0 <= i <= str.length()
    @post the letters in str at location i to the end have been converted to uppercase
  */
  void setStrToUpper(std::string& str,unsigned int i);
} //end namespace recur

#endif
