/**
 * Logan
 * Spring 2014
 *
 *   library of different implementations of a basic vector<int>
 *   initializer procedure * 
 */


#ifndef VRDEMO_H_
#define VRDEMO_H_

#include <vector>

/**
 *  The iter namespace contains an iterative, loop-based
 *  Implementation
 */
namespace iter{
  /**
   * setToIndex initializes all vector elements to be their
   *  index value
   * @param v is a reference to a vector<int>
   * @return none
   * @pre none
   * @post for all i in [0,v.size() ), v[i] = i for the 
   *   referenced vector
   */
  void setToIndex(std::vector<int> &v);
}

/**
 * the fstRst namespace contains a recursive implementation
 *   that uses first+Rest recursive traversal
 */
namespace fstRst{
  /**
   * setToIndex initializes all vector elements to be their
   *  index value
   * @param v is a reference to a vector<int>
   * @return none
   * @pre none
   * @post for all i in [0,v.size() ), v[i] = i for the 
   *   referenced vector
   */
  void setToIndex(std::vector<int> &v);

  /**
   * setToIndex initializes all vector elements in [fst,v.size() )
   *  to be their index value
   * @param v is a reference to a vector<int>
   * @param fst is the lower bound of the region to be initialized
   * @return none
   * @pre 0 <= fst <= v.size()
   * @post for all i in [fst,v.size() ), v[i] = i for the 
   *   referenced vector
   */
  void setToIndex(std::vector<int> &v, int fst);
}

namespace lstBLst{
  /**
   * setToIndex initializes all vector elements to be their
   *  index value
   * @param v is a reference to a vector<int>
   * @return none
   * @pre none
   * @post for all i in [0,v.size() ), v[i] = i for the 
   *   referenced vector
   */
  void setToIndex(std::vector<int> &v);
  
  /**
   * setToIndex initializes all vector elements in [0,lst )
   *  to be their index value
   * @param v is a reference to a vector<int>
   * @param lst is the upper exclusive bound of the region to be initialized
   * @return none
   * @pre 0 <= lst <= v.size()
   * @post for all i in [0,lst ), v[i] = i for the 
   *   referenced vector
   */
  void setToIndex(std::vector<int> &v, int lst);
}

#endif
