/**
 * Logan
 * Spring 2014
 *
 *  Implementation of the vrDemo.h library.
 */


#include <vector>
#include "vrDemo.h"

namespace iter{

  void setToIndex(std::vector<int> &v){
    
    // traverse left to right, index order
    for(unsigned int i(0); i < v.size() ; i++){
      v[i] = i;
    }

    // go right to left
    /*
    for(int i(v.size() -1 ); i >= 0 ; i--){
      v[i] = i;
    }
    */     

    return;
  }

}

namespace fstRst{
  void setToIndex(std::vector<int> &v){
    fstRst::setToIndex(v,0);
    return;
  }

  void setToIndex(std::vector<int> &v, int fst){
    if(fst == v.size() ){
      return;
    }
    else{
      v[fst] = fst;
      fstRst::setToIndex(v,fst+1);
    }
    return;
  }
}

namespace lstBLst{

  void setToIndex(std::vector<int> &v){
    lstBLst::setToIndex(v,v.size());
    return;
  }

  void setToIndex(std::vector<int> &v, int lst){
    if( lst == 0){
      return;
    }
    else{
      v[lst-1] = lst-1;
      lstBLst::setToIndex(v,lst-1);
    }
    return;
  }

}

