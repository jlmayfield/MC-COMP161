/**
 * Logan Mayfield
 * Spring 2014
 *
 *   Nothing for now
 */



#include <vector>
#include <iostream>
#include "vrDemo.h"


int main(int argc, char *argv[]){
  using namespace std;
  
  cout<< "Stubby\n";

  return 0;
}
