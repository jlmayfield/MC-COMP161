/**
 * Logan
 *
 */


#include "vrDemo.h"
#include <vector>
#include <gtest/gtest.h>


TEST(setToIndex,iter){
  using namespace std;

  vector<int> mt;
  iter::setToIndex(mt);
  EXPECT_EQ(vector<int>(),mt);

  vector<int> w(5,0);
  for(unsigned int i(0); i< w.size(); i++){
    w[i] = i;   
  }


  vector<int> v(5,2);
  for(unsigned int i(0); i < v.size() ; i++){
    EXPECT_EQ(2,v[i]);
  }
  iter::setToIndex(v);
  EXPECT_EQ(w,v);
  for(unsigned int i(0); i< v.size(); i++){
    EXPECT_EQ(i,v[i]);
  }
    
}

TEST(setToIndex,fstRst){
  using namespace std;

  vector<int> mt;
  fstRst::setToIndex(mt);
  EXPECT_EQ(vector<int>(),mt);

  vector<int> w(5,0);
  for(unsigned int i(0); i< w.size(); i++){
    w[i] = i;   
  }


  vector<int> v(5,2);
  for(unsigned int i(0); i < v.size() ; i++){
    EXPECT_EQ(2,v[i]);
  }
  fstRst::setToIndex(v);
  EXPECT_EQ(w,v);
  for(unsigned int i(0); i< v.size(); i++){
    EXPECT_EQ(i,v[i]);
  } 


}

TEST(setToIndex,fstRstHelp){
  using namespace std;
  
  vector<int> mt;
  fstRst::setToIndex(mt,0);
  EXPECT_EQ(vector<int>(),mt);

  vector<int> w(5,0);
  for(unsigned int i(0); i< w.size(); i++){
    w[i] = i;   
  }
  
  vector<int> v(5,2);
  fstRst::setToIndex(v,0);
  EXPECT_EQ(v,w);

  vector<int> v2(5,2);
  fstRst::setToIndex(v2,3);
  for(unsigned int i(0); i < v2.size() ; i++){
    if( i < 3 ){
      EXPECT_EQ(2,v2[i]);
    }
    else{
      EXPECT_EQ(i,v2[i]);
    }
  }
  
  

}

TEST(setToIndex,lstBLstHelp){
  using namespace std;

  vector<int> mt;
  lstBLst::setToIndex(mt,0);
  EXPECT_EQ(vector<int>(),mt);


  vector<int> w(5,0);
  for(unsigned int i(0); i< w.size(); i++){
    w[i] = i;   
  }


  vector<int> v(5,2);
  lstBLst::setToIndex(v,v.size());
  EXPECT_EQ(v,w);

  vector<int> v2(5,2);
  lstBLst::setToIndex(v2,3);
  for(unsigned int i(0); i < v2.size() ; i++){
    if( i < 3 ){
      EXPECT_EQ(i,v2[i]);
    }
    else{
      EXPECT_EQ(2,v2[i]);
    }
  }


}

TEST(setToIndex,lstBLst){
  using namespace std;

  vector<int> mt;
  lstBLst::setToIndex(mt);
  EXPECT_EQ(vector<int>(),mt);

  vector<int> w(5,0);
  for(unsigned int i(0); i< w.size(); i++){
    w[i] = i;   
  }


  vector<int> v(5,2);
  for(unsigned int i(0); i < v.size() ; i++){
    EXPECT_EQ(2,v[i]);
  }
 
  lstBLst::setToIndex(v);
  EXPECT_EQ(w,v);
  for(unsigned int i(0); i< v.size(); i++){
    EXPECT_EQ(i,v[i]);
  } 

 

}
