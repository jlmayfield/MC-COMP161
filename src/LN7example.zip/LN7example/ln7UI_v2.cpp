/*
Author: Logan Mayfield
Description: Example code from Lecture Notes 7

*/

#include <iostream>
#include <sstream>
#include "ln7UI_v2.h"

namespace ln7UI{

  void getPoint(char* args[],double& x,double& y){
    using namespace std;
    // Let's assume we typed numbers as arguments
    istringstream xstream(args[1]);
    xstream >> x;

    istringstream ystream(args[2]);
    ystream >> y;
    return;
  }

  void getRadius(char* args[], double& r){
    using namespace std;
    istringstream rstream(args[3]);
    rstream >> r;
    return;
  }

  void reportResults(double x,double y,double r,bool ans){
    using namespace std;
    cout << "isWithin( " << x <<" , " << y << " , " << r << " ) -> " <<
      std::boolalpha << ans << '\n';
    return;
  }

} //end namespace ln7UI
