/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include <iostream>
#include <sstream>
#include "ln7.h"

int main(int argc, char* argv[]){
  using namespace TwoD;
  using namespace std;

  double x{0.0};
  double y{0.0};
  double r{0.0};

  // Quick error check for enough arguments
  if( argc != 4 ){
    cerr << "Not enough arguments. Usage: " << argv[0] << " x y r\n";
    return 1;
  }

  // Let's assume we typed numbers as arguments
  istringstream xstream(argv[1]);
  xstream >> x;

  istringstream ystream(argv[2]);
  ystream >> y;

  istringstream rstream(argv[3]);
  rstream >> r;


  cout << "isWithin( " << x <<" , " << y << " , " << r << " ) -> " <<
    std::boolalpha << isWithin(x,y,r) << '\n';


  return 0;
}
