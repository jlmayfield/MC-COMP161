/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include "ln7.h"
#include "ln7UI.h"

int main(int argc, char* argv[]){
  using namespace ln7UI;
  using namespace std;

  double x{0.0};
  double y{0.0};
  double r{0.0};

  getPoint(x,y);
  getRadius(r);
  reportResults(x,y,r,TwoD::isWithin(x,y,r));

  return 0;
}
