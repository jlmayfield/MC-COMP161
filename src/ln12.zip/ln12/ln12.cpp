/*
  Author:
  Description: Library Definitions
*/

#include <random>
#include "ln12.h"

namespace ln12{

  unsigned int ndm(unsigned int n, unsigned int m,
		   std::default_random_engine& prng){

        std::uniform_int_distribution<unsigned int> d{1,m};

	unsigned int total{0};
	for( unsigned int i{0}; i < n ; ++i){
	  total += d(prng);
	}

    return total;
  }


} //end namespace ln12
