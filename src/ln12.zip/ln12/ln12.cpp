/**
  Logan Mayfield
*/

#include <iostream>
#include "ln12.h"


void toy::getValidNextNum(std::ostream& sout, std::istream& sin,
                          int& next){
    bool invalid{false};
    do{
      sout << "Enter a number between 1 and 5: ";
      int uin{0};
      sin >> uin;

      invalid = !(uin >= 1 && uin <= 5);
      if( invalid ){
        sout << "Expected a number between 1 and 5. Got "
             << uin << ". Please Try Again.\n";
      }
      else{
        // Don't update the state until it's validated
        next = uin;
      }
    }while( invalid );
    return;
}
