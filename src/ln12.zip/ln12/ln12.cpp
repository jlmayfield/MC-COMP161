/*
  Author: Logan Mayfield
  Description: Lecture Notes 12 example code

*/

#include <iostream>
#include <iomanip>
#include <cmath>
#include "ln12.h"

void ln12::printOdds(std::ostream& out, int max){
  int colWidth{ static_cast<int>(ceil(log10(max))) + 1};
  int numOdds{ static_cast<int>(ceil(max/2.0))};

  for(int i{0}; i < numOdds; i++){
    out << std::setw(colWidth) << (2*i + 1);
    if( i % 10 == 9 || i == numOdds-1){
      out << '\n';
    }
  }
  return;
}

void ln12::sumNums(std::istream& in, int& sum){

  sum = 0;
  int curr{0};
  do{
    in >> curr;
    if( in ){
      sum += curr;
    }
  }while( in );

  return;
}
