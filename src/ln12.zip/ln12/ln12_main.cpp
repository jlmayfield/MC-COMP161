/**
  Logan Mayfield
*/

#include "ln12.h"
#include <iostream>

int main(int argc, char* argv[]){

  for(int i{21}; i >=  13; i--){
    std::cout << i << ' ';
  }
  std::cout << '\n';
 

  int sum{0};
  int i{7};
  int n{33};
  do{
    sum += i;
    i += 2;
  }while( i < n );
  std::cout << sum << '\n';




  
  sum=0;
  i=0;
  int num_iters{ (n-7) / 2 };
  do{
    sum += (2*i + 7);
    
    i++;
  }while( i < num_iters  );
  std::cout << sum << '\n';

  int pow{n};
  while( pow >= 1 ){
    std::cout << pow << ' ';
    pow \= 2;
  }
  std::cout << '\n';
  
  return 0;
}// end main
