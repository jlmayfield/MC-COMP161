/*
  Author: Logan Mayfield
  Description: Random demo
*/

#include <iostream>
#include <random>
#include <chrono>
#include <algorithm>
#include <string>
#include <sstream>
#include <functional>

int main(int argc, char* argv[]){
  using namespace std;
  
  // declare seed
  unsigned int seed{0};

  // conditionally set value;
  if( argc == 1 ){
    auto clk = std::chrono::system_clock::now();
    auto time_in_ms = clk.time_since_epoch().count();
    seed = time_in_ms;
  }
  else if( argc == 2 ){
    istringstream arg{argv[1]};
    arg >> seed;
    if( arg.fail() ){
      cerr << "Bad CLI argument. Expecting unsigned integer value and got " << argv[1]  << "\n";
      return 1;
    }
  }
  else{ 
    cerr << "Too many CLI arguments.\n";
    return 1;
  }

  //  get a PRNG and seed it
  std::default_random_engine  gen{seed};
  
  // use min/max to see the range of the PRNG
  cout << "The default PRNG produces integers from [" << gen.min() << "," 
       << gen.max() <<"]\n";  

  cout << "\nSome numbers from the PRNG:\n";
  // Raw numbers from PRNG
  for(int i{0} ; i < 15 ; ++i){
    // print a random number from gen
    cout << gen();

    // space or newline depending on how many
    // numbers have been printed
    if( i % 5 == 4 ){
      cout << '\n';
    } 
    else{
      cout << ' ';
    }
  }
  cout << '\n';
  
  // declare a uniform distribution
  std::uniform_int_distribution<int> dist{1,6};

  // use the PRNG to pull numbers from that distribution
  cout << "30 rolls of a 6 sided die\n";
  for(int i{0} ; i < 30 ; ++i ){
    // dist(gen) gets a random number with respect to the distribution
    cout << dist(gen);

    if( i % 6 == 5 ){
      cout << '\n';
    } 
    else{
      cout << ' ';
    }
  }
  cout << '\n';


  // dice now acts like dist(gen)
  auto dice = std::bind ( dist, gen );
  cout << "\nYour wisdom is " << dice()+dice()+dice() << "\n\n";

  
  cout << "Shuffling \"hello world!\": \n";
  std::string str{"hello world!"};

  // use the PRNG to shuffle a string
  std::shuffle(begin(str),end(str),gen);
  
  std::cout << "The whole thing: "<<  str << '\n';

  str = std::string("hello world!");
  // shuffle part of a string
  std::shuffle(begin(str)+3,end(str)-3,gen);
  std::cout << "Not the first and last 3: " << str << '\n';

  
  return 0;
}
