/**
 Logan Mayfield
 File I/O demo code
 */

#include <iostream>
#include <fstream> // for ifstream and ofstream
#include "ln12.h"

int main(int argc, char* argv[]){
  std::ofstream ofile{"oddTable.txt"};

  ln12::printOdds(std::cout,50);
  ln12::printOdds(ofile,50);
  ofile.close();

  ofile.open("firstFive.txt");
  ln12::printOdds(ofile,10);
  ofile.close();

  std::ifstream infile{"firstFive.txt"};
  if( !infile.is_open() ){
    std::cerr << "Couldn't open file\n";
    return 1;
  }

  //1+3+5+7+9 = 25
  int thesum{0};
  ln12::sumNums(infile,thesum);
  std::cout << thesum << '\n';

  return 0;
}
