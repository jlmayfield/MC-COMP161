/*
Author: Logan Mayfield
Description: Lecture Notes 12 Example code
*/

#include <string>
#include <sstream>
#include "ln12.h"
#include <gtest/gtest.h>

namespace{

  TEST(stub,stub){
    
  }


}
