/*

 Logan Mayfield

*/

#include "ln12.h"
#include <gtest/gtest.h>
#include <sstream>
#include <string>


namespace{

  TEST(getvalid, all){
    std::string prompt{"Enter a number between 1 and 5: "};
    std::ostringstream ostr{""};
    std::istringstream istrm{""};
    int num{0};

    istrm.str("3");
    toy::getValidNextNum(ostr,istrm,num);
    EXPECT_EQ(3,num);
    EXPECT_EQ(prompt,ostr.str());



  }


} // end namespace
