/*
  Author:
  Description:
*/

#include <random>
#include "ln12.h"
#include <gtest/gtest.h>

namespace{

  TEST(ndm,all){
    
    std::default_random_engine prng;

    prng.seed(1);
    EXPECT_EQ(0,ln12::ndm(0,4,prng));

    prng.seed(1);
    EXPECT_EQ(0,ln12::ndm(0,6,prng));

    prng.seed(1);
    EXPECT_EQ(1,ln12::ndm(1,1,prng));

    prng.seed(1);
    EXPECT_EQ(5,ln12::ndm(5,1,prng));

    prng.seed(1);    
    EXPECT_EQ(1,ln12::ndm(1,4,prng));

    prng.seed(1);
    EXPECT_EQ(2,ln12::ndm(2,4,prng));

    prng.seed(1);
    EXPECT_EQ(11,ln12::ndm(5,4,prng));

    prng.seed(1);
    EXPECT_EQ(1,ln12::ndm(1,12,prng));

    prng.seed(1);
    EXPECT_EQ(60,ln12::ndm(10,12,prng));

  }

} // end namespace
