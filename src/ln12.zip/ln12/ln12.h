/*
  Author: Logan Mayfield
  Description: Lecture Notes 12 example code
*/

#ifndef _LN12_H_
#define _LN12_H_

#include <iostream>

namespace ln12{

    /**
     * Write a table of odd numbers to the stream out
     * with 10 numbers per row and columns aligned right
     * to fix the max number
     * @param out the stream where the odd numbers are written
     * @param max the largest possible number to be written
     * @return none
     * @pre max>=0
     * @post all the odds from [1,max] are written to out
     *  with 10 numbers per line
     */
    void printOdds(std::ostream& out, int max);

    /**
     * Sum the numbers found in a stream of integers
     * @param in the stream containing integers
     * @param sum the int variable to store the sum
     * @return none
     * @pre the tokens in the stream in are recognizable as
     *  integers.
     * @post sum is the sum of all the integers found in stream
     * in
     */
    void sumNums(std::istream& in, int& sum);

}

#endif
