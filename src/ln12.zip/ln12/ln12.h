/**
   Logan Mayfield
 */

#ifndef LN12_H_
#define LN12_H_

#include <iostream>

namespace toy{

  /**
   * Get a number between 1 and 5 from sin using sout for any
   *  prompts and reporting
   * @param sout output stream for prompts and errors
   * @param sin  input stream where user data is to be entered
   * @param next integer variable where number is to be stored
   * @return none
   * @pre sout and sin are not in an error state.
   * @post 1 <= next <= 5
   */
  void getValidNextNum(std::ostream& sout, std::istream& sin,
                            int& next);



}// end namespace ln12

#endif
