/*
  Author: Logan Mayfield
  Description: Library Definitions
*/

#include <vector>
#include "ln13.h"

namespace ln13{

  std::vector<double> squareAll(std::vector<double> v){
    
    //modify the v as it's a copy of the argument

    for(unsigned int i{0} ; i < v.size() ; i++ ){
      v[i] = v[i]*v[i];
    }

    return v;
  }
  
  int sum(const std::vector<int>& v){
    
    // initialize accumulator(s)
    int acc(0);
    
    //traverse [0,v.size() ) in least to greatest order
    for(unsigned int i(0); i < v.size() ; i++){
      // update the accumulator
      acc += v[i];
    }
    //return the completed accumulation
    return acc;
  }

} //end namespace ln13
