/*
  Author: Logan Mayfield
  Description: Library Declarations and Documentation
*/


#ifndef _LN13_H_
#define _LN13_H_

#include <vector>

namespace ln13{

  /** 
   * Compute the vector containing the squares of 
   * all the elements of v.
   * @param v a vector of doubles
   * @return the squares of v 
   * @pre none
   * @post none
   **/
  std::vector<double> squareAll(std::vector<double> v);

  /**
   * sum will return the sum of contents of a vector of ints
   * @param v is a vector of ints
   * @return the sum of the contents of v
   * @pre none
   * @post none
   */
  int sum(const std::vector<int>& v );


} //end namespace ln13


#endif
