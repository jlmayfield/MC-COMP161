/*
  Author: Logan Mayfield
  Description: Library Tests
*/

#include <vector>
#include "ln13.h"
#include <gtest/gtest.h>



namespace{

  TEST(vectorvariants,all){
    using namespace std;

    vector<int> v;
    EXPECT_TRUE(v.empty());
    EXPECT_EQ(0,v.size());
    
    vector<double> w{0.1, 0.2, 0.3, 0.4, 0.5};
    EXPECT_FALSE(w.empty());
    EXPECT_EQ(5,w.size());



  } 

  TEST(vectorselection,all){
    using namespace std;

    vector<int> v{1, 2, 3, 4, 5};
    vector<int> w{1, 2, 3, 4, 5};

    for(unsigned int i(0); i<v.size() ; i ++){
      EXPECT_EQ(i+1,w[i]);
      EXPECT_EQ(i+1,w.at(i));
    }

    EXPECT_EQ(v,w);

  }

  TEST(vectorElementMutation,all){
    using namespace std;

    // v is 125 instances of 'a'
    vector<char> v(125,'a');
    
    // change all the 'a's to 'A's
    for(unsigned int i(0); i<v.size() ; i++){
      v[i] = toupper(v[i]);
    }
    
    // test for expected change at each location
    for(unsigned int i(0); i<v.size(); i++){
      EXPECT_EQ('A',v[i]);
    }
 
    // or alternatively. 
    vector<char> w(125,'A');
    EXPECT_EQ(w,v);
  }

  TEST(sum,all){

    std::vector<int> mt;
    EXPECT_EQ(0,ln13::sum(mt));
    
    std::vector<int> notMT{1,2,3,4,5};
    EXPECT_EQ(15,ln13::sum(notMT));

  }

  TEST(sqall,all){
    
    std::vector<double> mt;
    EXPECT_EQ(mt,ln13::squareAll(mt));

    std::vector<double> v{0.1,0.2,0.3,0.4,0.5};
    std::vector<double> expected{0.01,0.04,0.09,0.16,0.25};
    std::vector<double> actual{ln13::squareAll(v)};
    for( unsigned int i{0}; i < v.size() ; ++i){
      EXPECT_DOUBLE_EQ(expected[i],actual[i]);
    }

  }

} // end namespace
