/**


 */

#ifndef LAB8_H_
#define LAB8_H_

#include <vector>

namespace lab8{

  namespace recur{
    /**
     * Find the maximum value in the vector<double> v.
     * @param v the vector
     * @return the max value in v
     * @pre TODO
     * @post TODO
     */
    double max(const std::vector<double>& v);

  }

  namespace iter{
    /**
     * Find the maximum value in the vector<double> v.
     * @param v the vector
     * @return the max value in v
     * @pre TODO
     * @post TODO
     */
    double max(const std::vector<double>& v);

  }
}

#endif
