/**


 */

#include <gtest/gtest.h>
#include <vector>
#include "lab8.h"


namespace {

  TEST(max,iter){
    // TODO
  }

  TEST(max,recur){
    // TODO
  }

}
