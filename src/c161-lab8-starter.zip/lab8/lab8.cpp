/**



 */

#include <vector>
#include "lab8.h"



double lab8::recur::max(const std::vector<double>& v){
  return 0.0;
}

double lab8::iter::max(const std::vector<double>& v){
  return 0.0;
}
