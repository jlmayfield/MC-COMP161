/*
Author:
Description:
*/

#include "my_type.h"

namespace type{

    //my_type::my_type() : {}

    my_type::my_type(/* fields */) {}

    my_type::my_type(my_type& other) {}

    my_type& my_type::operator=(const my_type lhs){
        return *this;
    }

    bool my_type::operator==(const my_type lhs) const{
       return false;
    }

} // end namespace
