/*
Author:
Description:
*/


#include "my_type.h"
#include <gtest/gtest.h>

namespace{

  TEST(stub,stub){}

} // end namespace
