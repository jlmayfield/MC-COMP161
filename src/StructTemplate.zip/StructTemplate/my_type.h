/*
  Author:
  Description:
*/

#ifndef _MY_TYPE_H
#define _MY_TYPE_H

namespace type{

  struct my_type{
    /*fields*/

    //my_type();

    my_type(/* fields */);

    my_type(my_type&);

    my_type& operator=(const my_type);

    bool operator==(const my_type) const;

  }; // end struct

} // end namespace

#endif
