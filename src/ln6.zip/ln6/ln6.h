/*
  Author:  Logan Mayfield
  Description: Example function from Lecture Notes 6

*/

#ifndef _LN6_H_
#define _LN6_H_

namespace practice{

  /*
   * Compute the cube of integer x
   * @param x a number
   * @return the cube of x
   * @pre none
   */
  int cube(int x);

  /*
   * Compute the y coordinate from the slope and
   *  intercept of a line and an x coordinate on that line.
   * @param m the slope of the line
   * @param b the intercept of the line
   * @param x the x coordinate
   * @return the y cooridinate
   * @pre none
   */
  double y_coord(double m, double b, double x);

  /*
   * Compute the taxes for a given income
   * @param income The individual income which can fall
   *    into three different tax brackets
   * @return taxes owed
   * @pre none
   */
   double my_taxes(double income);

} //end namespace practice


namespace pred1{

  /*
   * Determine if integer n is even or not.
   * @param n integer value
   * @return true if n is even, false if its odd
   * @pre none
   */
   bool isEven(int n);
}

namespace pred2{

  /*
   * Determine if integer n is even or not.
   * @param n integer value
   * @return true if n is even, false if its odd
   * @pre none
   */
   bool isEven(int n);

}

namespace pred3{

  /*
   * Determine if integer n is even or not.
   * @param n integer value
   * @return true if n is even, false if its odd
   * @pre none
   */
   bool isEven(int n);

}

namespace pred4{

  /*
   * Determine if integer n is even or not.
   * @param n integer value
   * @return true if n is even, false if its odd
   * @pre none
   */
   bool isEven(int n);

}

#endif
