/*
Author:  Logan Mayfield
Description: Unit tests for code from lecture notes 6

*/

#include "ln6.h"
#include <gtest/gtest.h>

namespace{

  TEST(cube,all){

    EXPECT_EQ(0,practice::cube(0));
    EXPECT_EQ(1,practice::cube(1));
    EXPECT_EQ(-1,practice::cube(-1));
    EXPECT_EQ(1000,practice::cube(10));
  }

  TEST(ycoord,all){
    using namespace practice;

    EXPECT_DOUBLE_EQ(0.0,y_coord(0.0,0.0,0.0));
    EXPECT_DOUBLE_EQ(1.0,y_coord(1.0,0.0,1.0));
    EXPECT_DOUBLE_EQ(2.0,y_coord(1.0,1.0,1.0));
    EXPECT_NEAR(-30.375, y_coord(-2.5,1.3,12.67), 0.00001);

  }

  TEST(myTaxes,negatives){


     EXPECT_DOUBLE_EQ(0.0,practice::my_taxes(-0.001) );
     EXPECT_DOUBLE_EQ(0.0 ,practice::my_taxes(-2000.0) );
     EXPECT_DOUBLE_EQ(0.0 ,practice::my_taxes(-1234.56) );
     EXPECT_DOUBLE_EQ(0.0 ,practice::my_taxes(-5.0) );

  }

  TEST(myTaxes,from0to500){

     EXPECT_DOUBLE_EQ(0.0 ,practice::my_taxes(0.0) );
     EXPECT_DOUBLE_EQ(20.0 ,practice::my_taxes(200.0) );
     EXPECT_DOUBLE_EQ(10.0 ,practice::my_taxes(100.0) );
     EXPECT_DOUBLE_EQ(37.55 ,practice::my_taxes(375.5) );
     EXPECT_DOUBLE_EQ(50.0 ,practice::my_taxes(500.0) );
  }

  TEST(myTaxes,from501to1000){

     EXPECT_DOUBLE_EQ(75.15 ,practice::my_taxes(501.0) );
     EXPECT_DOUBLE_EQ(90.0 ,practice::my_taxes(600.0) );
     EXPECT_DOUBLE_EQ(112.5 ,practice::my_taxes(750.0) );
     EXPECT_DOUBLE_EQ(150.0 ,practice::my_taxes(1000.0) );

  }

  TEST(myTaxes,from1000up){

     EXPECT_DOUBLE_EQ(250.0025 ,practice::my_taxes(1000.01) );
     EXPECT_DOUBLE_EQ(500.0 , practice::my_taxes(2000.0) );
     EXPECT_DOUBLE_EQ(2500.0 ,practice::my_taxes(10000.0) );
     EXPECT_DOUBLE_EQ(25000.0 ,practice::my_taxes(100000.0) );
  }

  TEST(iseven,v1){

    EXPECT_TRUE(pred1::isEven(0));
    EXPECT_TRUE(pred1::isEven(2));
    EXPECT_TRUE(pred1::isEven(8));
    EXPECT_TRUE(pred1::isEven(12));
    EXPECT_TRUE(pred1::isEven(1923132));
    EXPECT_FALSE(pred1::isEven(1));
    EXPECT_FALSE(pred1::isEven(3));
    EXPECT_FALSE(pred1::isEven(7));
    EXPECT_FALSE(pred1::isEven(189421));

  }

  TEST(iseven,v2){

    EXPECT_TRUE(pred2::isEven(0));
    EXPECT_TRUE(pred2::isEven(8));
    EXPECT_TRUE(pred2::isEven(2));
    EXPECT_TRUE(pred2::isEven(12));
    EXPECT_TRUE(pred2::isEven(1923132));
    EXPECT_FALSE(pred2::isEven(1));
    EXPECT_FALSE(pred2::isEven(3));
    EXPECT_FALSE(pred2::isEven(7));
    EXPECT_FALSE(pred2::isEven(1897421));

  }

  TEST(iseven,v3){

    EXPECT_TRUE(pred3::isEven(0));
    EXPECT_TRUE(pred3::isEven(2));
    EXPECT_TRUE(pred3::isEven(8));
    EXPECT_TRUE(pred3::isEven(12));
    EXPECT_TRUE(pred3::isEven(19232));
    EXPECT_FALSE(pred3::isEven(1));
    EXPECT_FALSE(pred3::isEven(3));
    EXPECT_FALSE(pred3::isEven(7));
    EXPECT_FALSE(pred3::isEven(18971));

  }

  TEST(iseven,v4){


    EXPECT_TRUE( pred4::isEven(0));
    EXPECT_TRUE( pred4::isEven(8));
    EXPECT_TRUE( pred4::isEven(2));
    EXPECT_TRUE( pred4::isEven(12));
    EXPECT_TRUE( pred4::isEven(192332));
    EXPECT_FALSE( pred4::isEven(1));
    EXPECT_FALSE( pred4::isEven(3));
    EXPECT_FALSE( pred4::isEven(7));
    EXPECT_FALSE( pred4::isEven(189421));

  }

} // end namespace
