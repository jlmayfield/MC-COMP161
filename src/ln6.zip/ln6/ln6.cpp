/*
  Author:  Logan Mayfield
  Description: Definitions for example functions from lecture notes 06
*/

#include "ln6.h"

namespace practice{

  int cube(int x){
    return (x*x*x);
  }

  double y_coord(double m, double b, double x){
    return b + m*x;
  }

  double my_taxes(double income){

    if( income < 0.0 ){ // (-inf,0.0)
      return 0.0;
    }
    else if( income <= 500.0 ){ //[0,500]
       return income * 0.1;
    }
    else if( income <= 1000.0 ){ //[501,1000]
       return income * 0.15;
    }
    else{   //(1000,inf)
       return income * 0.25;
    }

  }

} //end namespace practice

namespace pred1{

  bool isEven(int n){
    if( n % 2 == 0 ){
      return true;
    }
    else{
      return false;
    }
  }

}


namespace pred2{

  bool isEven(int n){
    return n % 2 == 0;
  }

}

namespace pred3{

  bool isEven(int n){
    if( n % 2 != 0 ){
      return false;
    }
    else{
      return true;
    }
  }

}

namespace pred4{

  bool isEven(int n){
    return !(n % 2 != 0 );
  }

}
