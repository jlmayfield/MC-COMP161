/*
  Author:  Logan Mayfield
  Description: Definitions for example functions from lecture notes 06
*/

#include "ln6.h"

namespace practice{

  int cube(int x){
    return (x*x*x);
  }
}

double practice::y_coord(double m, double b, double x){
  return b + m*x;
}

double practice::my_taxes(double income){

  if( income < 0.0 ){ // (-inf,0.0)
    return 0.0;
  }
  else if( income <= 500.0 ){ //[0,500]
     return income * 0.1;
  }
  else if( income <= 1000.0 ){ //[501,1000]
     return income * 0.15;
  }
  else{   //(1000,inf)
     return income * 0.25;
  }

}

bool pred1::isEven(int n){
  if( n % 2 == 0 ){
    return true;
  }
  else{
    return false;
  }
}

bool pred2::isEven(int n){
  return n % 2 == 0;
}

bool pred3::isEven(int n){
  if( n % 2 != 0 ){
    return false;
  }
  else{
    return true;
  }
}

bool pred4::isEven(int n){
  return !(n % 2 != 0 );
}
