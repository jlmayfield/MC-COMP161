/*
  Author: Logan Mayfield
  Description: Example code from lecture notes 7

*/

#ifndef _LN7_H_
#define _LN7_H_

namespace TwoD{

  /**
    * Determine if the point (x,y) is on or within a
    * circle with center (0,0) and radius r
    * @param x the x coordinate of the point
    * @param y the y coordinate of the point
    * @param r the radius of the circle
    * @return true if (x,y) is in or within the circle
    * @pre radius r is positive or 0
    */
   bool isWithin(double x, double y, double r);

} //end namespace TwoD

#endif
