/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include <iostream> //std::cout, std::cin, std::boolalpha
#include "ln7.h"

int main(int argc, char* argv[]){

  // explicit infinite loop
  // This is a terrible idea more often than not, but
  // works for this application.
  while( true ){

    // Variable Declaration
    double x{0.0};
    double y{0.0};
    double r{0.0};

    // Read
    std::cout << "Enter point coordinates: ";
    std::cin >> x >> y;
    std::cout << "Enter circle radius: ";
    std::cin >> r;

    // Eval+Print
    std::cout << "isWithin( " << x <<" , " << y << " , " << r << " ) -> " <<
      std::boolalpha << TwoD::isWithin(x,y,r) << '\n';
  } // end while(true)

  return 0;
} // end main
