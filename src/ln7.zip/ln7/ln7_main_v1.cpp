/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include <iostream>
#include "ln7.h"

int main(int argc, char* argv[]){

  double x(0.0);
  double y{0.0};
  double r{0.0};

  // explicit infinite loop
  // This is a terrible idea more often than not, but
  // works for this application.
  while(true){

    std::cout << "Enter point coordinates: ";
    std::cin >> x >> y;
    std::cout << "Enter circle radius: ";
    std::cin >> r;
    std::cout << "isWithin( " << x <<" , " << y << " , " << r << " ) -> " <<
      std::boolalpha << TwoD::isWithin(x,y,r) << '\n';
  }

  return 0;
}
