/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include <iostream> //cerr
#include "ln7.h"
#include "ln7UI_v2.h"

int main(int argc, char* argv[]){
  using namespace ln7UI;
  using namespace std;

  if( argc != 4 ){
    cerr << "Not enough arguments. Usage: " << argv[0] << " x y r\n";
    return 1;
  }

  double x{0.0};
  double y{0.0};
  double r{0.0};

  getPoint(argv,x,y);
  getRadius(argv,r);
  reportResults(x,y,r,TwoD::isWithin(x,y,r));

  return 0;
}
