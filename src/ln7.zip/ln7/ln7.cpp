/*
Author: Logan Mayfield
Description: Example code from Lecture Notes 7

*/

#include <cmath>
#include "ln7.h"

bool TwoD::isWithin(double x, double y, double r){
    return r >= sqrt(x*x + y*y);
 }
