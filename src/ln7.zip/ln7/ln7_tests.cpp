/*
Author: Logan Mayfield
Description: Example code from LN7

*/

#include "ln7.h"
#include <gtest/gtest.h>

namespace{

  TEST(isWithin,all){

  // Positive Tests
  EXPECT_TRUE(TwoD::isWithin(0,0,0));
  EXPECT_TRUE(TwoD::isWithin(0,0,0.5));
  EXPECT_TRUE(TwoD::isWithin(0,0,2.5));
  EXPECT_TRUE(TwoD::isWithin(1.0,0.5,2.5));
  EXPECT_TRUE(TwoD::isWithin(2.5,0.0,2.5));
  EXPECT_TRUE(TwoD::isWithin(0.0,2.5,2.5));

  // Negative Tests
  EXPECT_FALSE(TwoD::isWithin(1.0,0,0));
  EXPECT_FALSE(TwoD::isWithin(0,1.0,0.5));
  EXPECT_FALSE(TwoD::isWithin(2.5,2.5,2.5));
  EXPECT_FALSE(TwoD::isWithin(0,0.501,0.5));
  EXPECT_FALSE(TwoD::isWithin(2.5,0.1,2.5));
  EXPECT_FALSE(TwoD::isWithin(0.0,3.0,2.5));

  }

  TEST(vars,get){

    char achar{'a'};
    bool isOK{false};
    int  size{15};
    double amplitude{0.707};

    EXPECT_EQ('a',achar);
    EXPECT_EQ('A',toupper(achar));

    EXPECT_FALSE(isOK);
    EXPECT_TRUE(!isOK);
    EXPECT_TRUE(isOK || !isOK);

    EXPECT_EQ(15,size);
    EXPECT_EQ(-3,size-18);
    EXPECT_EQ(33,2*size+3);

    EXPECT_DOUBLE_EQ(0.707,amplitude);
    EXPECT_DOUBLE_EQ(1.414,2*amplitude);

  }

  TEST(vars,set){

    char achar{'a'};

    // BEFORE and AFTER
    EXPECT_EQ('a',achar);
    achar = 'x'; //mutation
    EXPECT_NE('a',achar); // not 'a'
    EXPECT_EQ('x',achar); // is 'x'

    //assignment can be done as an expression.
    //Can, but shouldn't.
    EXPECT_EQ('x',achar); //before
    EXPECT_EQ('b',achar = 'b'); //assignment expression
    EXPECT_EQ('b',achar); // after mutation

    int x{4};
    EXPECT_EQ(4,x);
    x += 6;
    EXPECT_EQ(10,x);
    // update assignemnt also has value
    EXPECT_EQ(6,x-=4);

    // ++x vs x++
    // this applies to -- as well

    x = 0;
    EXPECT_EQ(0,x);
    EXPECT_EQ(1,++x);
    EXPECT_EQ(1,x);
    EXPECT_EQ(1,x++);
    EXPECT_EQ(2,x);

  }

} // end namespace
