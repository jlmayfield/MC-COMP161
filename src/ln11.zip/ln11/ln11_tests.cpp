/*
Author: Logan Mayfield
Description: Lecture Notes 10 Example code
*/

#include <string>
#include "ln11.h"
#include <gtest/gtest.h>

namespace{

  TEST(setStrToUpper,iter){

    std::string s{""};

    iter::setStrToUpper(s);
    EXPECT_EQ(std::string(""),s);

    s = std::string("to");
    iter::setStrToUpper(s);
    EXPECT_EQ(std::string("TO"),s);

    s = std::string("DO");
    iter::setStrToUpper(s);
    EXPECT_EQ(std::string("DO"),s);

    s = std::string("hEllO");
    iter::setStrToUpper(s);
    EXPECT_EQ(std::string("HELLO"),s);
  }

  TEST(setStrToUpper,recur){

    std::string s{""};

    recur::setStrToUpper(s);
    EXPECT_EQ(std::string(""),s);

    s = std::string("to");
    recur::setStrToUpper(s);
    EXPECT_EQ(std::string("TO"),s);

    s = std::string("DO");
    recur::setStrToUpper(s);
    EXPECT_EQ(std::string("DO"),s);

    s = std::string("hEllO");
    recur::setStrToUpper(s);
    EXPECT_EQ(std::string("HELLO"),s);
  }

  TEST(setStrToUpper,recur2){

    std::string s{""};

    recur::setStrToUpper(s,0);
    EXPECT_EQ(std::string(""),s);

    s = "hello";
    recur::setStrToUpper(s,0);
    EXPECT_EQ(std::string("HELLO"),s);

    s = "hello";
    recur::setStrToUpper(s,1);
    EXPECT_EQ(std::string("hELLO"),s);

    s = "hello";
    recur::setStrToUpper(s,3);
    EXPECT_EQ(std::string("helLO"),s);

  }

  TEST(setStrToUpper,badrecur){

    std::string s{""};

    recur::badIdea::setStrToUpper(s);
    EXPECT_EQ(std::string(""),s);

    s = std::string("to");
    recur::badIdea::setStrToUpper(s);
    EXPECT_EQ(std::string("TO"),s);

    s = std::string("DO");
    recur::badIdea::setStrToUpper(s);
    EXPECT_EQ(std::string("DO"),s);

    s = std::string("hEllO");
    recur::badIdea::setStrToUpper(s);
    EXPECT_EQ(std::string("HELLO"),s);
  }

  TEST(strToUpper,iter2){

    // empty case
    EXPECT_EQ(std::string(""),iter::ver2::strToUpper(std::string("")));

    // other cases
    EXPECT_EQ(std::string("A"),iter::ver2::strToUpper(std::string("a")));

    EXPECT_EQ(std::string("DOG"),
    iter::ver2::strToUpper(std::string("dog")));

    EXPECT_EQ(std::string("CAT"),
    iter::ver2::strToUpper(std::string("Cat")));
  }

  TEST(strToUpper,iter3){

    // empty case
    EXPECT_EQ(std::string(""),iter::ver3::strToUpper(std::string("")));

    // other cases
    EXPECT_EQ(std::string("A"),iter::ver3::strToUpper(std::string("a")));

    EXPECT_EQ(std::string("DOG"),
    iter::ver3::strToUpper(std::string("dog")));

    EXPECT_EQ(std::string("CAT"),
    iter::ver3::strToUpper(std::string("Cat")));
  }

  TEST(strToUpper,iter4){

    // empty case
    EXPECT_EQ(std::string(""),iter::ver4::strToUpper(std::string("")));

    // other cases
    EXPECT_EQ(std::string("A"),iter::ver4::strToUpper(std::string("a")));

    EXPECT_EQ(std::string("DOG"),
    iter::ver4::strToUpper(std::string("dog")));

    EXPECT_EQ(std::string("CAT"),
    iter::ver4::strToUpper(std::string("Cat")));
  }

  TEST(strToUpper,recur){

    // empty case
    EXPECT_EQ(std::string(""),recur::strToUpper(std::string("")));

    // other cases
    EXPECT_EQ(std::string("A"),recur::strToUpper(std::string("a")));

    EXPECT_EQ(std::string("DOG"),
    recur::strToUpper(std::string("dog")));

    EXPECT_EQ(std::string("CAT"),
    recur::strToUpper(std::string("Cat")));
  }


} // end namespace
